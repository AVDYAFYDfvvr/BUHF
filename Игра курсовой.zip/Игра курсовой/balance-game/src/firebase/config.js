import { initializeApp } from 'firebase/app'
import { getAuth, connectAuthEmulator } from 'firebase/auth'
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: "AIzaSyCyeBOD6OIpqYIinfQ8wPBUY3NbD_xafQM",
  authDomain: "game-e41fb.firebaseapp.com",
  projectId: "game-e41fb",
  storageBucket: "game-e41fb.firebasestorage.app",
  messagingSenderId: "614533075360",
  appId: "1:614533075360:web:ce059dfab565ec57d414c5",
  measurementId: "G-LDC5Q9T9GF"
};

// Инициализация Firebase
const app = initializeApp(firebaseConfig)

// Экспорт сервисов
export const auth = getAuth(app)
export const db = getFirestore(app)
export default app