<template>
  <div id="app" :class="[settings.theme, `scheme-${settings.colorScheme}`]">
    <ParticleBackground />
    <HeaderNav />
    <AppLoader />
    <main class="main-content">
      <router-view v-slot="{ Component, route }">
        <transition :name="transitionName" mode="out-in">
          <component :is="Component" :key="route.path" />
        </transition>
      </router-view>
    </main>
    <AppFooter />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import HeaderNav from './components/HeaderNav.vue'
import AppFooter from './components/AppFooter.vue'
import AppLoader from './components/AppLoader.vue'
import { useSettings } from './composables/useSettings'
import { useItems } from './composables/useItems'
import { useAuth } from './composables/useAuth'

const { settings } = useSettings()
const { initItems } = useItems()
const { initAuth } = useAuth()
const router = useRouter()

const transitionName = ref('fade')

router.beforeEach((to, from) => {
  if (!from.name) transitionName.value = 'fade'
  else if (to.path === '/create') transitionName.value = 'slide-up'
  else if (to.path === '/') transitionName.value = 'slide-right'
  else if (to.path.includes('/admin')) transitionName.value = 'zoom'
  else transitionName.value = 'slide-left'
})

onMounted(() => { initAuth(); initItems() })
</script>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
  font-family: 'Inter', 'Montserrat', 'Segoe UI', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  letter-spacing: -0.01em;
  line-height: 1.6;
}

#app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

/* ========== СВЕТЛАЯ ТЕМА ========== */
#app.light {
  background: linear-gradient(135deg, #f5f7fa 0%, #e8ecf1 50%, #f0f2f5 100%);
  background-attachment: fixed;
  color: #1a1a2e;
}

/* ========== ТЁМНАЯ ТЕМА ========== */
#app.dark {
  background: linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%);
  background-attachment: fixed;
  color: #e8e8f0;
}

/* ========== ОБЩИЕ СТИЛИ ========== */
#app.dark .screen,
#app.dark .tab-content,
#app.dark .setting-card,
#app.dark .stat-card,
#app.dark .chart-section,
#app.dark .mode-stats,
#app.dark .item-card,
#app.dark .item-filters,
#app.dark .about-card,
#app.dark .edit-form-container,
#app.dark .empty-state,
#app.dark .error-state {
  background: rgba(30, 30, 50, 0.95) !important;
  backdrop-filter: blur(20px) !important;
  color: #e8e8f0 !important;
  border: 1px solid rgba(255, 255, 255, 0.05) !important;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3) !important;
}

#app.dark .card-title,
#app.dark .setting-card h3,
#app.dark .chart-section h2,
#app.dark .mode-stats h2,
#app.dark .about-section h2,
#app.dark h2, #app.dark h3, #app.dark h4 {
  color: #ffffff !important;
  font-weight: 700 !important;
  letter-spacing: -0.02em !important;
}

#app.dark p, #app.dark span, #app.dark label,
#app.dark .card-description, #app.dark .stat-label, #app.dark .meta-date {
  color: #b0b0c0 !important;
  font-weight: 400 !important;
}

#app.dark input, #app.dark select, #app.dark textarea {
  background: rgba(40, 40, 60, 0.8) !important;
  color: #e8e8f0 !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
  border-radius: 14px !important;
  backdrop-filter: blur(10px) !important;
}

#app.dark input::placeholder, #app.dark textarea::placeholder { color: #666 !important; }
#app.dark input:focus, #app.dark select:focus, #app.dark textarea:focus {
  border-color: #667eea !important;
  box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15) !important;
}

#app.dark .btn-secondary {
  background: rgba(60, 60, 80, 0.8) !important;
  color: #e8e8f0 !important;
  backdrop-filter: blur(10px) !important;
}

#app.dark .mode-btn {
  background: rgba(40, 40, 60, 0.8) !important;
  color: #b0b0c0 !important;
}

#app.dark .mode-btn.active {
  background: linear-gradient(135deg, #667eea, #764ba2) !important;
  color: white !important;
}

#app.dark table th {
  background: rgba(40, 40, 60, 0.8) !important;
  color: #e8e8f0 !important;
  font-weight: 600 !important;
}

#app.dark table td { color: #b0b0c0 !important; border-color: rgba(255, 255, 255, 0.05) !important; }
#app.dark tr:hover { background: rgba(255, 255, 255, 0.03) !important; }

#app.dark .playground {
  background: linear-gradient(135deg, #0a0a20, #1a1a35) !important;
  box-shadow: inset 0 0 40px rgba(0, 0, 0, 0.5) !important;
}

#app.dark .controls-info {
  background: rgba(30, 30, 50, 0.8) !important;
  color: #e8e8f0 !important;
  backdrop-filter: blur(10px) !important;
}

#app.dark .leaderboard {
  background: rgba(30, 30, 50, 0.8) !important;
  backdrop-filter: blur(10px) !important;
}

#app.dark .leaderboard-tab.active {
  background: rgba(40, 40, 60, 0.8) !important;
  color: #667eea !important;
}

#app.dark .footer {
  background: linear-gradient(135deg, #0a0a15, #0f0f20) !important;
  border-top: 1px solid rgba(255, 255, 255, 0.05) !important;
}

/* Стекло-эффект для светлой темы */
.screen, .item-card, .about-card, .setting-card, .chart-section, .mode-stats, .edit-form-container {
  background: rgba(255, 255, 255, 0.9) !important;
  backdrop-filter: blur(20px) !important;
  border: 1px solid rgba(255, 255, 255, 0.8) !important;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06) !important;
  border-radius: 24px !important;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
}

.item-card:hover {
  transform: translateY(-6px) !important;
  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.12) !important;
}

/* Красивые кнопки */
.btn-primary, .btn-submit {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
  color: white !important;
  border: none !important;
  padding: 14px 35px !important;
  font-size: 1.05em !important;
  font-weight: 700 !important;
  border-radius: 50px !important;
  cursor: pointer !important;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3) !important;
  letter-spacing: -0.01em !important;
  position: relative !important;
  overflow: hidden !important;
}

.btn-primary::after, .btn-submit::after {
  content: '' !important;
  position: absolute !important;
  top: 0; left: -100%; width: 100%; height: 100% !important;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent) !important;
  transition: left 0.5s !important;
}

.btn-primary:hover::after, .btn-submit:hover::after { left: 100% !important; }
.btn-primary:hover, .btn-submit:hover {
  transform: translateY(-3px) !important;
  box-shadow: 0 12px 35px rgba(102, 126, 234, 0.45) !important;
}

/* Инпуты светлой темы */
input, select, textarea {
  border-radius: 14px !important;
  border: 2px solid rgba(0, 0, 0, 0.08) !important;
  padding: 12px 18px !important;
  font-size: 0.95em !important;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
  font-family: inherit !important;
  background: rgba(255, 255, 255, 0.9) !important;
}

input:focus, select:focus, textarea:focus {
  border-color: #667eea !important;
  box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1) !important;
  outline: none !important;
}

/* Заголовки */
h1, h2, h3, h4, h5, h6 {
  font-family: 'Montserrat', 'Inter', sans-serif !important;
  font-weight: 800 !important;
  letter-spacing: -0.03em !important;
  line-height: 1.2 !important;
}

h1 { font-size: 2.8em !important; }
h2 { font-size: 2em !important; }

/* Скроллбар */
::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: rgba(102, 126, 234, 0.3); border-radius: 20px; }
::-webkit-scrollbar-thumb:hover { background: rgba(102, 126, 234, 0.5); }

/* Цветовые схемы */
#app.scheme-ocean .header,
#app.scheme-ocean .btn-primary,
#app.scheme-ocean .btn-submit,
#app.scheme-ocean .stat-card,
#app.scheme-ocean .auth-tab.active {
  background: linear-gradient(135deg, #2193b0, #6dd5ed) !important;
}

#app.scheme-forest .header,
#app.scheme-forest .btn-primary,
#app.scheme-forest .btn-submit,
#app.scheme-forest .stat-card,
#app.scheme-forest .auth-tab.active {
  background: linear-gradient(135deg, #11998e, #38ef7d) !important;
}

#app.scheme-sunset .header,
#app.scheme-sunset .btn-primary,
#app.scheme-sunset .btn-submit,
#app.scheme-sunset .stat-card,
#app.scheme-sunset .auth-tab.active {
  background: linear-gradient(135deg, #f12711, #f5af19) !important;
}

/* Футер */
.footer {
  background: linear-gradient(135deg, #1a1a2e, #16213e) !important;
  color: white !important;
}

.main-content { flex: 1; padding: 20px; }

/* ========== АНИМАЦИИ ========== */
.fade-enter-active, .fade-leave-active { transition: opacity 0.35s ease, transform 0.35s ease; }
.fade-enter-from { opacity: 0; transform: translateY(15px); }
.fade-leave-to { opacity: 0; transform: translateY(-15px); }

.slide-left-enter-active, .slide-left-leave-active { transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
.slide-left-enter-from { opacity: 0; transform: translateX(40px); }
.slide-left-leave-to { opacity: 0; transform: translateX(-40px); }

.slide-right-enter-active, .slide-right-leave-active { transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
.slide-right-enter-from { opacity: 0; transform: translateX(-40px); }
.slide-right-leave-to { opacity: 0; transform: translateX(40px); }

.slide-up-enter-active, .slide-up-leave-active { transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1); }
.slide-up-enter-from { opacity: 0; transform: translateY(60px) scale(0.95); }
.slide-up-leave-to { opacity: 0; transform: translateY(-60px) scale(0.95); }

.zoom-enter-active, .zoom-leave-active { transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1); }
.zoom-enter-from { opacity: 0; transform: scale(0.8); }
.zoom-leave-to { opacity: 0; transform: scale(1.2); }

@media (max-width: 768px) { 
  .main-content { padding: 12px; } 
  h1 { font-size: 2em !important; }
}
@media (max-width: 480px) { 
  .main-content { padding: 8px; } 
}
</style>