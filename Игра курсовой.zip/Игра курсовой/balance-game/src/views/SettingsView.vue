<template>
  <div class="settings-view">
    <h1>⚙️ Настройки</h1>
    
    <div class="settings-grid">
      <div class="setting-card">
        <h3>🎨 Тема</h3>
        <div class="toggle-group">
          <button @click="setTheme('light')" :class="{ active: settings.theme === 'light' }">☀️ Светлая</button>
          <button @click="setTheme('dark')" :class="{ active: settings.theme === 'dark' }">🌙 Тёмная</button>
        </div>
      </div>

      <div class="setting-card">
        <h3>🌈 Цветовая схема</h3>
        <div class="color-presets">
          <button v-for="p in presets" :key="p.id" @click="setColorScheme(p.id)"
            :class="{ active: settings.colorScheme === p.id }" :style="{ background: p.color }">
            {{ p.name }}
          </button>
        </div>
      </div>

      <div class="setting-card">
        <h3>📋 Режим отображения</h3>
        <div class="toggle-group">
          <button @click="setViewMode('cards')" :class="{ active: settings.viewMode === 'cards' }">🃏 Карточки</button>
          <button @click="setViewMode('table')" :class="{ active: settings.viewMode === 'table' }">📊 Таблица</button>
        </div>
      </div>

      <div class="setting-card">
        <h3>⚠️ Подтверждение удаления</h3>
        <div class="toggle-group">
          <button @click="setConfirmDelete(true)" :class="{ active: settings.confirmDelete }">✅ Включено</button>
          <button @click="setConfirmDelete(false)" :class="{ active: !settings.confirmDelete }">❌ Выключено</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useSettings } from '../composables/useSettings'

const { settings, setTheme, setColorScheme, setViewMode, setConfirmDelete } = useSettings()

const presets = [
  { id: 'default', name: 'По умолчанию', color: 'linear-gradient(135deg, #667eea, #764ba2)' },
  { id: 'ocean', name: 'Океан', color: 'linear-gradient(135deg, #2193b0, #6dd5ed)' },
  { id: 'forest', name: 'Лес', color: 'linear-gradient(135deg, #11998e, #38ef7d)' },
  { id: 'sunset', name: 'Закат', color: 'linear-gradient(135deg, #f12711, #f5af19)' }
]
</script>

<style scoped>
.settings-view { max-width: 800px; margin: 0 auto; padding: 30px 20px; }
h1 { text-align: center; background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; background-clip: text; color: transparent; margin-bottom: 30px; font-size: 2.5em; }
.settings-grid { display: grid; gap: 20px; }
.setting-card { background: white; border-radius: 20px; padding: 25px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); transition: background 0.3s; }
:global(.dark) .setting-card { background: #2a2a3e; color: #f0f0f0; }
.setting-card h3 { margin-bottom: 15px; color: #333; }
:global(.dark) .setting-card h3 { color: #f0f0f0; }
.toggle-group { display: flex; gap: 10px; }
.toggle-group button { flex: 1; padding: 10px; border: 2px solid #e0e0e0; border-radius: 12px; background: white; cursor: pointer; font-weight: 500; transition: all 0.2s; }
.toggle-group button.active { background: linear-gradient(135deg, #667eea, #764ba2); color: white; border-color: transparent; box-shadow: 0 4px 15px rgba(102,126,234,0.3); }
.color-presets { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
.color-presets button { padding: 12px; border: none; border-radius: 12px; color: white; font-weight: 600; cursor: pointer; transition: all 0.2s; }
.color-presets button.active { transform: scale(1.05); box-shadow: 0 4px 15px rgba(0,0,0,0.3); }
@media (max-width: 480px) { .toggle-group { flex-direction: column; } .color-presets { grid-template-columns: 1fr; } }
</style>