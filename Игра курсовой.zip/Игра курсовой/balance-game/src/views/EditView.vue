<template>
  <div v-if="isAdmin" class="edit-view">
    <div class="page-header">
      <h1>✏️ Редактирование</h1>
      <button @click="$router.push('/')" class="back-link">← На главную</button>
    </div>
    
    <div v-if="loading" class="loading-state">
      <div class="spinner"></div>
      <p>Загрузка...</p>
    </div>
    
    <div v-else-if="!item" class="error-state">
      <span class="error-icon">⚠️</span>
      <h2>Элемент не найден</h2>
      <p>Запрашиваемая запись не существует или была удалена.</p>
      <button @click="$router.push('/')" class="btn-primary">🏠 На главную</button>
    </div>
    
    <div v-else class="edit-form-container">
      <ItemForm
        :initial-item="item"
        @submit="handleUpdate"
        @cancel="handleCancel"
      />
    </div>
  </div>

  <div v-else class="access-denied">
    <h1>🚫 Доступ запрещён</h1>
    <p>Только для администраторов</p>
    <button @click="$router.push('/')" class="btn-primary">🏠 На главную</button>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import ItemForm from '../components/ItemForm.vue'
import { getItems } from '../services/storage'
import { useAuth } from '../composables/useAuth'

const route = useRoute()
const router = useRouter()
const { isAdmin } = useAuth()

const loading = ref(true)
const item = ref(null)

onMounted(() => {
  if (!isAdmin.value) {
    loading.value = false
    return
  }

  const id = route.params.id
  
  if (!id) {
    loading.value = false
    return
  }

  // НЕ используем useItems() - читаем напрямую из localStorage
  try {
    const allItems = getItems()
    const found = allItems.find(i => i.id === id && !i.deletedAt)
    item.value = found || null
  } catch (e) {
    item.value = null
  }

  loading.value = false
})

const handleUpdate = (formData) => {
  if (!item.value) return

  // Обновляем напрямую в localStorage
  const allItems = getItems()
  const index = allItems.findIndex(i => i.id === item.value.id)
  
  if (index !== -1) {
    allItems[index] = {
      ...allItems[index],
      title: formData.title.trim(),
      description: formData.description.trim(),
      category: formData.category
    }
    localStorage.setItem('balance_game_items', JSON.stringify(allItems))
  }

  alert('✅ Изменения сохранены!')
  router.push('/')
}

const handleCancel = () => {
  router.push('/')
}
</script>

<style scoped>
.edit-view {
  max-width: 800px;
  margin: 0 auto;
  padding: 30px 20px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
}

.page-header h1 {
  font-size: 2.5em;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.back-link {
  color: #667eea;
  background: none;
  border: none;
  cursor: pointer;
  font-weight: 500;
  padding: 8px 16px;
  border-radius: 20px;
  transition: background 0.2s;
  font-size: 1em;
}

.back-link:hover {
  background: rgba(102, 126, 234, 0.1);
}

.loading-state {
  text-align: center;
  padding: 60px 20px;
}

.spinner {
  width: 50px;
  height: 50px;
  border: 4px solid #e0e0e0;
  border-top-color: #667eea;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  margin: 0 auto 20px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.error-state {
  text-align: center;
  padding: 60px 30px;
  background: white;
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.error-icon {
  font-size: 4em;
  display: block;
  margin-bottom: 20px;
}

.error-state h2 {
  color: #333;
  margin-bottom: 15px;
}

.error-state p {
  color: #666;
  margin-bottom: 30px;
}

.btn-primary {
  display: inline-block;
  padding: 14px 35px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  border: none;
  border-radius: 25px;
  font-weight: bold;
  cursor: pointer;
  transition: transform 0.2s;
  font-size: 1em;
}

.btn-primary:hover {
  transform: translateY(-2px);
}

.edit-form-container {
  background: white;
  border-radius: 20px;
  padding: 30px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.access-denied {
  text-align: center;
  padding: 100px 20px;
}

.access-denied h1 {
  font-size: 3em;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  margin-bottom: 15px;
}

.access-denied p {
  color: #666;
  margin-bottom: 30px;
}

@media (max-width: 768px) {
  .page-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 15px;
  }
  
  .page-header h1 {
    font-size: 2em;
  }
  
  .edit-form-container {
    padding: 20px;
  }
}
</style>