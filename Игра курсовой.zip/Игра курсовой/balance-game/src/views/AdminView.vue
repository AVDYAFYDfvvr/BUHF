<template>
  <div class="admin-view" v-if="isAdmin">
    <h1>👑 Панель администратора</h1>
    
    <div class="admin-tabs">
      <button v-for="tab in tabs" :key="tab.id" @click="activeTab = tab.id"
        :class="{ active: activeTab === tab.id }">{{ tab.icon }} {{ tab.name }}</button>
    </div>

    <!-- Пользователи -->
    <div v-if="activeTab === 'users'" class="tab-content">
      <h2>👥 Пользователи ({{ users.length }})</h2>
      <div class="table-wrapper">
        <table>
          <thead><tr><th>Имя</th><th>Email</th><th>Роль</th><th>Игр</th><th>Очков</th><th>Статус</th><th>Действия</th></tr></thead>
          <tbody>
            <tr v-for="user in users" :key="user.id">
              <td>{{ user.displayName }}</td>
              <td>{{ user.email }}</td>
              <td><span :class="['badge', user.role]">{{ user.role }}</span></td>
              <td>{{ user.gamesPlayed || 0 }}</td>
              <td>{{ user.totalScore || 0 }}</td>
              <td><span :class="['status', user.isBlocked ? 'blocked' : 'active']">{{ user.isBlocked ? 'Заблокирован' : 'Активен' }}</span></td>
              <td class="actions">
                <button @click="changeRole(user)" :disabled="user.uid === currentUser?.uid" title="Сменить роль">🔄</button>
                <button @click="toggleBlock(user)" :disabled="user.uid === currentUser?.uid" :title="user.isBlocked ? 'Разблокировать' : 'Заблокировать'">{{ user.isBlocked ? '✅' : '🚫' }}</button>
                <button @click="viewUserItems(user)" title="Записи пользователя">📋</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Контент -->
    <div v-if="activeTab === 'content'" class="tab-content">
      <div class="content-header">
        <h2>📦 Все записи ({{ filteredContent.length }})</h2>
        <div class="content-controls">
          <input type="text" v-model="contentSearch" placeholder="🔍 Поиск..." class="search-input">
          <select v-model="contentFilter" class="filter-select">
            <option value="all">Все</option>
            <option value="active">Активные</option>
            <option value="deleted">В корзине</option>
            <option value="done">Выполненные</option>
          </select>
          <button @click="refreshContent" class="refresh-btn">🔄</button>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <thead><tr><th>Название</th><th>Пользователь</th><th>Очки</th><th>Статус</th><th>Дата</th><th>Действия</th></tr></thead>
          <tbody>
            <tr v-for="item in filteredContent" :key="item.id" :class="{ deleted: item.deletedAt, done: item.isDone && !item.deletedAt }">
              <td>
                <strong>{{ item.title }}</strong>
                <div class="item-desc">{{ item.description }}</div>
              </td>
              <td>{{ item.userId?.slice(0, 8) }}...</td>
              <td>{{ item.score || 0 }}</td>
              <td>
                <span v-if="item.deletedAt" class="status deleted">В корзине</span>
                <span v-else-if="item.isDone" class="status done">Выполнено</span>
                <span v-else class="status active">Активно</span>
              </td>
              <td>{{ formatDate(item.createdAt) }}</td>
              <td class="actions">
                <button v-if="!item.deletedAt" @click="toggleItemDone(item)" :title="item.isDone ? 'Отменить' : 'Выполнить'">{{ item.isDone ? '↩️' : '✓' }}</button>
                <button v-if="!item.deletedAt" @click="editItem(item)" title="Редактировать">✏️</button>
                <button v-if="!item.deletedAt" @click="softDeleteItem(item)" title="В корзину">🗑️</button>
                <button v-if="item.deletedAt" @click="restoreItemFromTrash(item)" title="Восстановить">↩️</button>
                <button v-if="item.deletedAt" @click="deleteItemPermanently(item)" title="Удалить навсегда" class="danger">❌</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Модальное окно редактирования -->
      <Teleport to="body">
        <div v-if="editingItem" class="modal-overlay" @click.self="editingItem = null">
          <div class="modal-content edit-modal">
            <h3>✏️ Редактировать запись</h3>
            <div class="form-group">
              <label>Название</label>
              <input v-model="editingItem.title" type="text">
            </div>
            <div class="form-group">
              <label>Описание</label>
              <textarea v-model="editingItem.description" rows="3"></textarea>
            </div>
            <div class="form-group">
              <label>Категория</label>
              <select v-model="editingItem.category">
                <option value="balance">Balance Game</option>
                <option value="classic">Классика</option>
                <option value="endless">Испытание</option>
                <option value="master">Мастер</option>
              </select>
            </div>
            <div class="modal-actions">
              <button class="btn-save" @click="saveItemEdit">💾 Сохранить</button>
              <button class="btn-cancel" @click="editingItem = null">Отмена</button>
            </div>
          </div>
        </div>
      </Teleport>
    </div>

    <!-- Статистика -->
    <div v-if="activeTab === 'stats'" class="tab-content">
      <h2>📊 Статистика</h2>
      <div class="stats-grid">
        <div class="stat-box"><span class="big">{{ users.length }}</span>Пользователей</div>
        <div class="stat-box"><span class="big">{{ allItems.length }}</span>Всего записей</div>
        <div class="stat-box"><span class="big">{{ totalGames }}</span>Игр сыграно</div>
        <div class="stat-box"><span class="big">{{ blockedUsers }}</span>Заблокировано</div>
        <div class="stat-box"><span class="big">{{ activeItemsCount }}</span>Активных записей</div>
        <div class="stat-box"><span class="big">{{ deletedItemsCount }}</span>В корзине</div>
      </div>
    </div>

    <!-- Записи пользователя -->
    <div v-if="activeTab === 'userItems'" class="tab-content">
      <div class="content-header">
        <h2>📋 Записи: {{ selectedUser?.displayName }}</h2>
        <button @click="activeTab = 'users'; selectedUser = null" class="back-btn">← Назад</button>
      </div>
      <div class="table-wrapper">
        <table>
          <thead><tr><th>Название</th><th>Очки</th><th>Статус</th><th>Дата</th><th>Действия</th></tr></thead>
          <tbody>
            <tr v-for="item in userSpecificItems" :key="item.id">
              <td>{{ item.title }}</td>
              <td>{{ item.score || 0 }}</td>
              <td>{{ item.deletedAt ? 'В корзине' : item.isDone ? 'Выполнено' : 'Активно' }}</td>
              <td>{{ formatDate(item.createdAt) }}</td>
              <td class="actions">
                <button v-if="!item.deletedAt" @click="softDeleteItem(item)">🗑️</button>
                <button v-if="item.deletedAt" @click="restoreItemFromTrash(item)">↩️</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div v-else class="access-denied">
    <h1>🚫 Доступ запрещён</h1>
    <p>Только для администраторов</p>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useAuth } from '../composables/useAuth'
import { getAllUsers, getAllItems, updateUserRole, toggleUserBlock, deleteItemAdmin } from '../services/firebaseService'
import { useItems } from '../composables/useItems'

const { currentUser, isAdmin } = useAuth()
const { updateItem, toggleDone, softDelete, restoreItem, deleteForever } = useItems()

const activeTab = ref('users')
const tabs = [
  { id: 'users', name: 'Пользователи', icon: '👥' },
  { id: 'content', name: 'Контент', icon: '📦' },
  { id: 'stats', name: 'Статистика', icon: '📊' }
]

const users = ref([])
const allItems = ref([])
const contentSearch = ref('')
const contentFilter = ref('all')
const editingItem = ref(null)
const selectedUser = ref(null)
const userSpecificItems = ref([])

const filteredContent = computed(() => {
  let items = allItems.value

  if (contentFilter.value === 'active') items = items.filter(i => !i.deletedAt)
  else if (contentFilter.value === 'deleted') items = items.filter(i => i.deletedAt)
  else if (contentFilter.value === 'done') items = items.filter(i => i.isDone && !i.deletedAt)

  if (contentSearch.value) {
    const s = contentSearch.value.toLowerCase()
    items = items.filter(i => 
      i.title?.toLowerCase().includes(s) || 
      i.description?.toLowerCase().includes(s)
    )
  }

  return items.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))
})

const totalGames = computed(() => users.value.reduce((s, u) => s + (u.gamesPlayed || 0), 0))
const blockedUsers = computed(() => users.value.filter(u => u.isBlocked).length)
const activeItemsCount = computed(() => allItems.value.filter(i => !i.deletedAt).length)
const deletedItemsCount = computed(() => allItems.value.filter(i => i.deletedAt).length)

onMounted(async () => {
  if (isAdmin.value) await refreshAll()
})

const refreshAll = async () => {
  const [u, i] = await Promise.all([getAllUsers(), getAllItems()])
  if (u.success) users.value = u.users
  if (i.success) allItems.value = i.items
}

const refreshContent = async () => {
  const i = await getAllItems()
  if (i.success) allItems.value = i.items
}

const changeRole = async (user) => {
  const newRole = user.role === 'admin' ? 'user' : 'admin'
  if (confirm(`Сменить роль пользователя "${user.displayName}" на ${newRole}?`)) {
    const result = await updateUserRole(user.uid, newRole)
    if (result.success) user.role = newRole
  }
}

const toggleBlock = async (user) => {
  const action = user.isBlocked ? 'разблокировать' : 'заблокировать'
  if (confirm(`Вы уверены, что хотите ${action} пользователя "${user.displayName}"?`)) {
    const result = await toggleUserBlock(user.uid, !user.isBlocked)
    if (result.success) user.isBlocked = !user.isBlocked
  }
}

const viewUserItems = async (user) => {
  selectedUser.value = user
  activeTab.value = 'userItems'
  userSpecificItems.value = allItems.value.filter(i => i.userId === user.uid)
}

const toggleItemDone = (item) => {
  toggleDone(item.id)
  item.isDone = !item.isDone
}

const editItem = (item) => {
  editingItem.value = { ...item }
}

const saveItemEdit = () => {
  if (!editingItem.value) return
  updateItem(editingItem.value.id, {
    title: editingItem.value.title,
    description: editingItem.value.description,
    category: editingItem.value.category
  })
  
  const idx = allItems.value.findIndex(i => i.id === editingItem.value.id)
  if (idx !== -1) {
    allItems.value[idx] = { ...allItems.value[idx], ...editingItem.value }
  }
  
  editingItem.value = null
}

const softDeleteItem = async (item) => {
  if (confirm('Переместить в корзину?')) {
    softDelete(item.id)
    item.deletedAt = new Date()
  }
}

const restoreItemFromTrash = (item) => {
  restoreItem(item.id)
  item.deletedAt = null
}

const deleteItemPermanently = async (item) => {
  if (confirm('Удалить навсегда? Это действие нельзя отменить!')) {
    await deleteItemAdmin(item.id)
    allItems.value = allItems.value.filter(i => i.id !== item.id)
  }
}

const formatDate = (ts) => {
  if (!ts) return '-'
  const d = ts?.seconds ? new Date(ts.seconds * 1000) : new Date(ts)
  return d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}
</script>

<style scoped>
.admin-view { max-width: 1300px; margin: 0 auto; padding: 30px 20px; }
h1 { background: linear-gradient(135deg, #ffd700, #ff8c00); -webkit-background-clip: text; background-clip: text; color: transparent; margin-bottom: 25px; font-size: 2.5em; }
.admin-tabs { display: flex; gap: 10px; margin-bottom: 25px; flex-wrap: wrap; }
.admin-tabs button { padding: 12px 24px; border: none; border-radius: 25px; cursor: pointer; background: #f0f0f0; transition: all 0.2s; font-weight: 600; font-size: 1em; }
.admin-tabs button.active { background: linear-gradient(135deg, #ffd700, #ff8c00); color: #333; box-shadow: 0 4px 15px rgba(255,140,0,0.3); }
.tab-content { background: white; border-radius: 20px; padding: 25px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.content-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px; }
.content-controls { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
.search-input { padding: 8px 15px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 0.9em; outline: none; }
.search-input:focus { border-color: #ffa500; }
.filter-select { padding: 8px 15px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 0.9em; cursor: pointer; }
.refresh-btn { padding: 8px 15px; background: #f0f0f0; border: none; border-radius: 10px; cursor: pointer; font-size: 1.2em; }
.table-wrapper { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; min-width: 800px; }
th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; font-size: 0.9em; }
th { background: #f8f9fa; font-weight: 600; color: #333; position: sticky; top: 0; }
tr:hover { background: #fafafa; }
tr.deleted { opacity: 0.5; background: #fef5f5; }
tr.done { background: #f5fef5; }
.item-desc { font-size: 0.8em; color: #999; margin-top: 4px; }
.actions { display: flex; gap: 6px; }
.actions button { padding: 6px 10px; border: none; border-radius: 8px; cursor: pointer; font-size: 1em; transition: all 0.2s; background: #f0f0f0; }
.actions button:hover { transform: scale(1.1); background: #e0e0e0; }
.actions button:disabled { opacity: 0.4; cursor: not-allowed; }
.actions button.danger:hover { background: #ffebee; }
.badge { padding: 5px 12px; border-radius: 15px; font-size: 0.8em; font-weight: 600; text-transform: uppercase; }
.badge.admin { background: #ffd700; color: #333; }
.badge.user { background: #e0e0e0; color: #333; }
.status { font-size: 0.85em; font-weight: 500; }
.status.active, .status.done { color: #2e7d32; }
.status.blocked, .status.deleted { color: #c62828; }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }
.stat-box { background: linear-gradient(135deg, #fff8e1, #ffecb3); padding: 25px; border-radius: 20px; text-align: center; font-weight: 500; color: #666; }
.stat-box .big { display: block; font-size: 2.5em; font-weight: bold; color: #ff8c00; margin-bottom: 5px; }
.access-denied { text-align: center; padding: 100px 20px; }
.back-btn { padding: 8px 20px; background: #f0f0f0; border: none; border-radius: 15px; cursor: pointer; font-weight: 500; }
.modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(5px); display: flex; justify-content: center; align-items: center; z-index: 1000; }
.edit-modal { background: white; border-radius: 20px; padding: 30px; width: 90%; max-width: 500px; }
.edit-modal h3 { margin-bottom: 20px; }
.form-group { margin-bottom: 15px; }
.form-group label { display: block; margin-bottom: 5px; font-weight: 600; }
.form-group input, .form-group textarea, .form-group select { width: 100%; padding: 10px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 1em; font-family: inherit; }
.form-group input:focus, .form-group textarea:focus, .form-group select:focus { border-color: #ffa500; outline: none; }
.modal-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }
.btn-save, .btn-cancel { padding: 10px 25px; border: none; border-radius: 15px; cursor: pointer; font-weight: 600; }
.btn-save { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
.btn-cancel { background: #f0f0f0; color: #666; }
@media (max-width: 768px) { .tab-content { padding: 15px; } th, td { padding: 8px; font-size: 0.8em; } .edit-modal { padding: 20px; } }
</style>