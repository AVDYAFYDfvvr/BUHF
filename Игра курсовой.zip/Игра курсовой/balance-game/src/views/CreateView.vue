<template>
  <div class="create-view">
    <h1 class="page-title">🎮 Новая игра</h1>
    <p class="page-subtitle">Удерживайте шар в равновесии и установите новый рекорд!</p>
    
    <div v-if="currentUser" class="user-greeting">
      🎮 Играешь как <strong>{{ currentUser.displayName || 'Игрок' }}</strong>
    </div>
    <div v-else class="user-greeting guest">
      👤 Играешь как гость. <span class="login-hint" @click="showAuth">Войди</span>, чтобы сохранять рекорды в облаке!
    </div>
    
    <div class="game-wrapper">
      <GameBoard 
        :player-display-name="currentUser?.displayName || 'Гость'"
        @gameEnd="handleGameEnd" 
      />
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import GameBoard from '../components/GameBoard.vue'
import { useItems } from '../composables/useItems'
import { useAuth } from '../composables/useAuth'

const router = useRouter()
const { addItem } = useItems()
const { currentUser } = useAuth()

const showAuth = () => {
  // Можно добавить открытие модалки авторизации
  // Либо редирект на страницу входа
  alert('Нажми кнопку "Войти" в шапке сайта')
}

const handleGameEnd = async (result) => {
  await addItem({
    title: `Игра (${getModeName(result.mode)})`,
    description: `Счёт: ${result.score}, комбо: x${Math.floor(result.maxCombo / 10) + 1 || 1}`,
    category: 'balance',
    score: result.score,
    maxCombo: result.maxCombo,
    gameMode: result.mode
  })
  
  alert(`🎉 Игра завершена! Ваш счёт: ${result.score} очков сохранён.`)
}

const getModeName = (mode) => {
  const names = { classic: 'Классика', endless: 'Испытание', master: 'Мастер' }
  return names[mode] || mode
}
</script>

<style scoped>
.create-view {
  max-width: 1300px;
  margin: 0 auto;
  padding: 30px 20px;
}

.page-title {
  font-size: 2.5em;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  margin-bottom: 10px;
  text-align: center;
}

.page-subtitle {
  text-align: center;
  color: #666;
  font-size: 1.1em;
  margin-bottom: 15px;
}

.user-greeting {
  text-align: center;
  background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
  padding: 12px 20px;
  border-radius: 15px;
  margin-bottom: 25px;
  color: #2e7d32;
  font-weight: 500;
}

.user-greeting.guest {
  background: linear-gradient(135deg, #fff3e0, #ffe0b2);
  color: #e65100;
}

.login-hint {
  color: #667eea;
  cursor: pointer;
  text-decoration: underline;
  font-weight: 600;
}

.game-wrapper {
  border-radius: 35px;
  overflow: hidden;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
}

@media (max-width: 768px) {
  .page-title {
    font-size: 1.8em;
  }
}
</style>