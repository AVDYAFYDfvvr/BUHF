<template>
  <div class="not-found-view">
    <div class="not-found-content">
      <h1>404</h1>
      <h2>Страница не найдена</h2>
      <p>Извините, запрашиваемая страница не существует.</p>
      <router-link to="/" class="home-link">🏠 На главную</router-link>
    </div>
  </div>
</template>

<style scoped>
.not-found-view {
  min-height: 60vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px 20px;
}

.not-found-content {
  text-align: center;
  background: white;
  border-radius: 30px;
  padding: 50px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
  max-width: 500px;
}

.not-found-content h1 {
  font-size: 6em;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  margin: 0;
  line-height: 1;
}

.not-found-content h2 {
  font-size: 2em;
  color: #333;
  margin: 20px 0;
}

.not-found-content p {
  color: #666;
  margin-bottom: 30px;
}

.home-link {
  display: inline-block;
  padding: 12px 30px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  text-decoration: none;
  border-radius: 25px;
  font-weight: bold;
  transition: transform 0.2s;
}

.home-link:hover {
  transform: translateY(-2px);
}

@media (max-width: 768px) {
  .not-found-content {
    padding: 30px 20px;
  }
  
  .not-found-content h1 {
    font-size: 4em;
  }
  
  .not-found-content h2 {
    font-size: 1.5em;
  }
}
</style>