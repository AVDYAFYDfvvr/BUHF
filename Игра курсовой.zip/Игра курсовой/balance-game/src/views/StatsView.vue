<template>
  <div class="stats-view">
    <h1>📊 Статистика</h1>

    <div class="stats-summary">
      <div class="stat-card">
        <span class="stat-icon">🎮</span>
        <span class="stat-value">{{ totalCount }}</span>
        <span class="stat-label">Всего игр</span>
      </div>
      <div class="stat-card">
        <span class="stat-icon">✅</span>
        <span class="stat-value">{{ doneCount }}</span>
        <span class="stat-label">Завершено</span>
      </div>
      <div class="stat-card">
        <span class="stat-icon">⭐</span>
        <span class="stat-value">{{ bestScore }}</span>
        <span class="stat-label">Лучший счёт</span>
      </div>
      <div class="stat-card">
        <span class="stat-icon">🔥</span>
        <span class="stat-value">{{ bestCombo }}x</span>
        <span class="stat-label">Лучшее комбо</span>
      </div>
    </div>

    <div class="chart-section" v-if="currentUser">
      <h2>📈 Ваш прогресс</h2>
      <div class="bar-chart">
        <div v-for="bar in scoreHistory" :key="bar.label" class="bar-item">
          <div class="bar-fill" :style="{ height: bar.percent + '%' }"></div>
          <span class="bar-label">{{ bar.label }}</span>
          <span class="bar-value">{{ bar.value }}</span>
        </div>
      </div>
    </div>

    <div class="mode-stats">
      <h2>🎯 По режимам</h2>
      <div class="mode-grid">
        <div v-for="mode in ['classic', 'endless', 'master']" :key="mode" class="mode-card">
          <h3>{{ modeNames[mode] }}</h3>
          <p>Игр: {{ getModeCount(mode) }}</p>
          <p>Лучший: {{ getModeBest(mode) }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useItems } from '../composables/useItems'
import { useAuth } from '../composables/useAuth'

const { items, totalCount, doneCount } = useItems()
const { currentUser } = useAuth()

const modeNames = { classic: '🏁 Классика', endless: '⚡ Испытание', master: '🎯 Мастер' }

const gameItems = computed(() => items.value.filter(i => i.category === 'balance' && !i.deletedAt))

const bestScore = computed(() => {
  const scores = gameItems.value.map(i => i.score || 0)
  return scores.length ? Math.max(...scores) : 0
})

const bestCombo = computed(() => {
  const combos = gameItems.value.map(i => i.maxCombo || 0)
  return combos.length ? Math.max(...combos) : 0
})

const scoreHistory = computed(() => {
  const last5 = [...gameItems.value].sort((a, b) => a.createdAt - b.createdAt).slice(-5)
  const maxScore = Math.max(...last5.map(i => i.score || 0), 1)
  return last5.map((item, idx) => ({
    label: `#${idx + 1}`,
    value: item.score || 0,
    percent: ((item.score || 0) / maxScore) * 100
  }))
})

const getModeCount = (mode) => gameItems.value.filter(i => i.gameMode === mode).length
const getModeBest = (mode) => {
  const scores = gameItems.value.filter(i => i.gameMode === mode).map(i => i.score || 0)
  return scores.length ? Math.max(...scores) : 0
}
</script>

<style scoped>
.stats-view { max-width: 1000px; margin: 0 auto; padding: 30px 20px; }
h1 { text-align: center; background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; background-clip: text; color: transparent; font-size: 2.5em; margin-bottom: 30px; }
.stats-summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 20px; margin-bottom: 40px; }
.stat-card { background: white; border-radius: 20px; padding: 25px; text-align: center; box-shadow: 0 5px 20px rgba(0,0,0,0.1); transition: transform 0.2s; }
.stat-card:hover { transform: translateY(-5px); }
.stat-icon { font-size: 2.5em; display: block; margin-bottom: 10px; }
.stat-value { font-size: 2em; font-weight: bold; display: block; background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; background-clip: text; color: transparent; }
.stat-label { color: #666; font-size: 0.9em; }
.chart-section, .mode-stats { background: white; border-radius: 20px; padding: 25px; margin-bottom: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.chart-section h2, .mode-stats h2 { margin-bottom: 20px; color: #333; }
.bar-chart { display: flex; align-items: flex-end; gap: 25px; height: 200px; padding: 10px 0; }
.bar-item { flex: 1; display: flex; flex-direction: column; align-items: center; height: 100%; justify-content: flex-end; }
.bar-fill { width: 40px; background: linear-gradient(to top, #667eea, #764ba2); border-radius: 8px 8px 0 0; transition: height 0.5s ease; min-height: 4px; }
.bar-label { margin-top: 8px; font-size: 0.85em; color: #666; }
.bar-value { font-weight: bold; font-size: 0.85em; color: #333; margin-top: 4px; }
.mode-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.mode-card { background: linear-gradient(135deg, #f5f7fa, #e0e5ec); padding: 20px; border-radius: 15px; text-align: center; }
.mode-card h3 { margin-bottom: 10px; }
.mode-card p { color: #666; margin: 5px 0; }
@media (max-width: 768px) { .mode-grid { grid-template-columns: 1fr; } .bar-chart { gap: 15px; } .bar-fill { width: 30px; } }
</style>