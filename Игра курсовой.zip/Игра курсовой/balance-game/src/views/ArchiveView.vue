<template>
  <div class="archive-view">
    <div class="page-header">
      <h1>🗑️ Корзина</h1>
      <p>Удалённые записи ({{ deletedCount }} шт.)</p>
    </div>

    <ItemList :show-deleted="true" />

    <div v-if="deletedCount > 0" class="danger-zone">
      <h3>⚠️ Опасная зона</h3>
      <p>Это действие нельзя отменить!</p>
      <button @click="clearAll" class="btn-danger">🗑️ Очистить корзину</button>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import ItemList from '../components/ItemList.vue'
import { useItems } from '../composables/useItems'
import { useAuth } from '../composables/useAuth'

const { items, deletedCount, deleteForever } = useItems()
const { isAdmin } = useAuth()

const clearAll = () => {
  if (!isAdmin.value) return
  if (confirm('Удалить ВСЕ записи из корзины навсегда?')) {
    items.value.filter(i => i.deletedAt).forEach(i => deleteForever(i.id))
  }
}
</script>

<style scoped>
.archive-view { max-width: 1300px; margin: 0 auto; padding: 30px 20px; }
.page-header { text-align: center; margin-bottom: 30px; }
.page-header h1 { background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; background-clip: text; color: transparent; font-size: 2.5em; }
.page-header p { color: #666; margin-top: 10px; }
.danger-zone { margin-top: 40px; padding: 25px; background: #fff5f5; border: 2px dashed #ff4757; border-radius: 20px; text-align: center; }
.danger-zone h3 { color: #c62828; margin-bottom: 10px; }
.danger-zone p { color: #666; margin-bottom: 15px; }
.btn-danger { padding: 12px 30px; background: #ff4757; color: white; border: none; border-radius: 15px; font-weight: bold; cursor: pointer; transition: all 0.2s; }
.btn-danger:hover { background: #c62828; transform: translateY(-2px); }
</style>