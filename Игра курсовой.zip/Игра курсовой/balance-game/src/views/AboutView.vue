<template>
  <div class="about-view">
    <div class="about-card">
      <h1>ℹ️ О проекте</h1>
      
      <div class="about-section">
        <h2>🎮 Balance Master Pro</h2>
        <p>Интерактивная игра-балансир, разработанная в рамках курсового проекта.</p>
      </div>
      
      <div class="about-section">
        <h2>🛠️ Технологии</h2>
        <ul>
          <li>Vue 3 + Composition API</li>
          <li>Vue Router</li>
          <li>LocalStorage для хранения данных</li>
          <li>Адаптивная вёрстка</li>
          <li>Canvas для визуальных эффектов</li>
        </ul>
      </div>
      
      <div class="about-section">
        <h2>📊 Статистика</h2>
        <div class="stats-grid">
          <div class="stat-item">
            <span class="stat-value">{{ totalCount }}</span>
            <span class="stat-label">Всего игр</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ activeCount }}</span>
            <span class="stat-label">Активных</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ doneCount }}</span>
            <span class="stat-label">Завершено</span>
          </div>
        </div>
      </div>
      
      <div class="about-section">
        <h2>👨‍💻 Разработчик</h2>
        <p>Курсовой проект по дисциплине "Веб-технологии"</p>
        <p>2026 год</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useItems } from '../composables/useItems'

const { totalCount, activeCount, doneCount } = useItems()
</script>

<style scoped>
.about-view {
  max-width: 800px;
  margin: 0 auto;
  padding: 40px 20px;
}

.about-card {
  background: white;
  border-radius: 30px;
  padding: 40px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
}

.about-card h1 {
  font-size: 2.5em;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  margin-bottom: 30px;
  text-align: center;
}

.about-section {
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 1px solid #eee;
}

.about-section:last-child {
  border-bottom: none;
}

.about-section h2 {
  color: #333;
  margin-bottom: 15px;
  font-size: 1.3em;
}

.about-section p {
  color: #666;
  line-height: 1.6;
  margin-bottom: 10px;
}

.about-section ul {
  list-style: none;
  padding: 0;
}

.about-section li {
  padding: 8px 0;
  color: #666;
  padding-left: 25px;
  position: relative;
}

.about-section li::before {
  content: '✓';
  color: #667eea;
  position: absolute;
  left: 0;
  font-weight: bold;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
  margin-top: 15px;
}

.stat-item {
  text-align: center;
  padding: 15px;
  background: linear-gradient(135deg, #f5f7fa, #e0e5ec);
  border-radius: 15px;
}

.stat-value {
  display: block;
  font-size: 2em;
  font-weight: bold;
  color: #667eea;
}

.stat-label {
  font-size: 0.9em;
  color: #666;
}

@media (max-width: 768px) {
  .about-card {
    padding: 25px;
  }
  
  .about-card h1 {
    font-size: 2em;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
    gap: 10px;
  }
}
</style>