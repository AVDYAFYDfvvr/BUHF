<template>
  <div class="home-view">
    <div class="hero-section" ref="heroRef" :style="heroStyle">
      <div class="hero-content">
        <h1>🏆 Balance Master</h1>
        <p class="hero-subtitle">Ваши игровые достижения</p>
        <div class="hero-stats">
          <div class="hero-stat" v-for="stat in heroStats" :key="stat.label">
            <span class="hero-stat-value">{{ stat.value }}</span>
            <span class="hero-stat-label">{{ stat.label }}</span>
          </div>
        </div>
      </div>
      <div class="hero-bg-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
      </div>
    </div>
    
    <ItemFilters :filter="filter" :count="filteredCount" @update:filter="updateFilter" />
    <ItemList :filter="filter" :show-deleted="false" />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import ItemFilters from '../components/ItemFilters.vue'
import ItemList from '../components/ItemList.vue'
import { useItems } from '../composables/useItems'
import { useAuth } from '../composables/useAuth'

const { items, totalCount, doneCount } = useItems()
const { currentUser } = useAuth()

const filter = ref({ search: '', category: '', status: '' })
const heroRef = ref(null)
const scrollY = ref(0)
const mouseX = ref(0)
const mouseY = ref(0)

const updateFilter = (f) => { filter.value = f }

const filteredCount = computed(() => {
  let filtered = items.value.filter(i => !i.deletedAt)
  if (filter.value.category) filtered = filtered.filter(i => i.category === filter.value.category)
  if (filter.value.status === 'done') filtered = filtered.filter(i => i.isDone)
  else if (filter.value.status === 'active') filtered = filtered.filter(i => !i.isDone)
  if (filter.value.search) {
    const s = filter.value.search.toLowerCase()
    filtered = filtered.filter(i => i.title.toLowerCase().includes(s) || i.description.toLowerCase().includes(s))
  }
  return filtered.length
})

const heroStats = computed(() => [
  { value: totalCount.value, label: 'Всего игр' },
  { value: doneCount.value, label: 'Завершено' },
  { value: currentUser.value?.displayName || 'Гость', label: 'Игрок' }
])

const heroStyle = computed(() => ({
  transform: `translateY(${scrollY.value * 0.3}px)`,
  backgroundPosition: `${50 + mouseX.value * 0.02}% ${50 + mouseY.value * 0.02}%`
}))

const onScroll = () => { scrollY.value = window.scrollY }
const onMouseMove = (e) => { mouseX.value = e.clientX - window.innerWidth / 2; mouseY.value = e.clientY - window.innerHeight / 2 }

onMounted(() => { window.addEventListener('scroll', onScroll); window.addEventListener('mousemove', onMouseMove) })
onBeforeUnmount(() => { window.removeEventListener('scroll', onScroll); window.removeEventListener('mousemove', onMouseMove) })
</script>

<style scoped>
.home-view { max-width: 1300px; margin: 0 auto; padding: 30px 20px; }
.hero-section {
  position: relative;
  background: linear-gradient(135deg, #667eea, #764ba2, #f093fb);
  border-radius: 30px;
  padding: 60px 40px;
  margin-bottom: 40px;
  overflow: hidden;
  transition: background-position 0.1s ease;
  background-size: 200% 200%;
}
.hero-content { position: relative; z-index: 2; text-align: center; }
.hero-section h1 { font-size: 3.5em; color: white; margin-bottom: 10px; text-shadow: 0 2px 10px rgba(0,0,0,0.3); }
.hero-subtitle { color: rgba(255,255,255,0.9); font-size: 1.3em; margin-bottom: 30px; }
.hero-stats { display: flex; justify-content: center; gap: 40px; }
.hero-stat { text-align: center; }
.hero-stat-value { display: block; font-size: 2.5em; font-weight: bold; color: white; }
.hero-stat-label { color: rgba(255,255,255,0.8); font-size: 0.9em; }
.hero-bg-shapes { position: absolute; inset: 0; z-index: 1; }
.shape {
  position: absolute; border-radius: 50%; background: rgba(255,255,255,0.1);
  animation: floatShape 6s ease-in-out infinite;
}
.shape-1 { width: 150px; height: 150px; top: -30px; left: -30px; animation-delay: 0s; }
.shape-2 { width: 100px; height: 100px; bottom: 20px; right: 10%; animation-delay: 2s; }
.shape-3 { width: 80px; height: 80px; top: 50%; right: -20px; animation-delay: 4s; }
@keyframes floatShape {
  0%, 100% { transform: translate(0, 0) rotate(0deg); }
  33% { transform: translate(20px, -20px) rotate(120deg); }
  66% { transform: translate(-10px, 15px) rotate(240deg); }
}
@media (max-width: 768px) {
  .hero-section { padding: 40px 20px; }
  .hero-section h1 { font-size: 2em; }
  .hero-stats { gap: 20px; flex-wrap: wrap; }
}
</style>