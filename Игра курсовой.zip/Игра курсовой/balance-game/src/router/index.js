import { createRouter, createWebHistory } from 'vue-router'
import { useLoader } from '../composables/useLoader'
import { useAuth } from '../composables/useAuth'

import HomeView from '../views/HomeView.vue'
import CreateView from '../views/CreateView.vue'
import EditView from '../views/EditView.vue'
import AboutView from '../views/AboutView.vue'
import AdminView from '../views/AdminView.vue'
import ArchiveView from '../views/ArchiveView.vue'
import StatsView from '../views/StatsView.vue'
import SettingsView from '../views/SettingsView.vue'
import NotFoundView from '../views/NotFoundView.vue'

const routes = [
  { path: '/', name: 'home', component: HomeView },
  { path: '/create', name: 'create', component: CreateView },
  { path: '/edit/:id', name: 'edit', component: EditView },
  { path: '/about', name: 'about', component: AboutView },
  { path: '/archive', name: 'archive', component: ArchiveView },
  { path: '/stats', name: 'stats', component: StatsView },
  { path: '/settings', name: 'settings', component: SettingsView },
  { path: '/admin', name: 'admin', component: AdminView, meta: { requiresAdmin: true } },
  { path: '/:pathMatch(.*)*', name: 'not-found', component: NotFoundView }
]

const router = createRouter({ history: createWebHistory(), routes })

router.beforeEach((to, from, next) => {
  const { showLoader } = useLoader()
  showLoader()
  if (to.meta.requiresAdmin && !useAuth().isAdmin.value) next('/')
  else next()
})

router.afterEach(() => {
  setTimeout(() => useLoader().hideLoader(), 400)
})

export default router