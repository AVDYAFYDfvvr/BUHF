import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth'
import { 
  collection, addDoc, getDocs, updateDoc, deleteDoc, doc, query, where, orderBy, limit, serverTimestamp, setDoc
} from 'firebase/firestore'
import { auth, db } from '../firebase/config'

export const registerUser = async (email, password, displayName) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    await updateProfile(userCredential.user, { displayName: displayName || email.split('@')[0] })
    
    await setDoc(doc(db, 'users', userCredential.user.uid), {
      uid: userCredential.user.uid,
      email: email,
      displayName: displayName || email.split('@')[0],
      role: 'user',
      createdAt: serverTimestamp(),
      lastLogin: serverTimestamp(),
      totalScore: 0,
      gamesPlayed: 0,
      isBlocked: false
    })
    
    return { success: true, user: userCredential.user }
  } catch (error) {
    let message = error.message
    if (error.code === 'auth/email-already-in-use') message = 'Этот email уже зарегистрирован'
    else if (error.code === 'auth/weak-password') message = 'Пароль слишком слабый'
    else if (error.code === 'auth/invalid-email') message = 'Некорректный email'
    return { success: false, error: message }
  }
}

export const loginUser = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    
    const userDoc = await getDocs(query(collection(db, 'users'), where('uid', '==', userCredential.user.uid)))
    if (!userDoc.empty) {
      const userData = userDoc.docs[0].data()
      if (userData.isBlocked) {
        await signOut(auth)
        return { success: false, error: 'Ваш аккаунт заблокирован' }
      }
      await updateDoc(doc(db, 'users', userDoc.docs[0].id), { lastLogin: serverTimestamp() })
    }
    
    return { success: true, user: userCredential.user }
  } catch (error) {
    let message = error.message
    if (error.code === 'auth/user-not-found') message = 'Пользователь не найден'
    else if (error.code === 'auth/wrong-password') message = 'Неверный пароль'
    else if (error.code === 'auth/too-many-requests') message = 'Слишком много попыток'
    return { success: false, error: message }
  }
}

export const logoutUser = async () => {
  try { await signOut(auth); return { success: true } }
  catch (error) { return { success: false, error: error.message } }
}

export const onAuthChange = (callback) => {
  return onAuthStateChanged(auth, (user) => callback(user), () => callback(null))
}

export const getCurrentUserData = async (uid) => {
  try {
    const q = query(collection(db, 'users'), where('uid', '==', uid))
    const snap = await getDocs(q)
    if (!snap.empty) return { success: true, data: { id: snap.docs[0].id, ...snap.docs[0].data() } }
    return { success: false }
  } catch (error) { return { success: false, error: error.message } }
}

export const getAllUsers = async () => {
  try {
    const snap = await getDocs(collection(db, 'users'))
    return { success: true, users: snap.docs.map(d => ({ id: d.id, ...d.data() })) }
  } catch (error) { return { success: false, error: error.message } }
}

export const updateUserRole = async (userId, role) => {
  try {
    const q = query(collection(db, 'users'), where('uid', '==', userId))
    const snap = await getDocs(q)
    if (!snap.empty) {
      await updateDoc(doc(db, 'users', snap.docs[0].id), { role })
      return { success: true }
    }
    return { success: false, error: 'Пользователь не найден' }
  } catch (error) { return { success: false, error: error.message } }
}

export const toggleUserBlock = async (userId, isBlocked) => {
  try {
    const q = query(collection(db, 'users'), where('uid', '==', userId))
    const snap = await getDocs(q)
    if (!snap.empty) {
      await updateDoc(doc(db, 'users', snap.docs[0].id), { isBlocked })
      return { success: true }
    }
    return { success: false }
  } catch (error) { return { success: false, error: error.message } }
}

export const getAllItems = async () => {
  try {
    const snap = await getDocs(query(collection(db, 'items'), orderBy('createdAt', 'desc')))
    return { success: true, items: snap.docs.map(d => ({ id: d.id, ...d.data() })) }
  } catch (error) { return { success: false, error: error.message } }
}

export const deleteItemAdmin = async (itemId) => {
  try { await deleteDoc(doc(db, 'items', itemId)); return { success: true } }
  catch (error) { return { success: false } }
}

export const getUserItems = async (userId) => {
  try {
    const q = query(collection(db, 'items'), where('userId', '==', userId))
    const snap = await getDocs(q)
    return { success: true, items: snap.docs.map(d => ({ id: d.id, ...d.data() })) }
  } catch (error) { return { success: false, error: error.message } }
}

export const addItemToFirestore = async (item) => {
  try {
    const docRef = await addDoc(collection(db, 'items'), { ...item, createdAt: serverTimestamp(), updatedAt: serverTimestamp() })
    return { success: true, id: docRef.id }
  } catch (error) { return { success: false, error: error.message } }
}

export const updateItemInFirestore = async (itemId, updates) => {
  try {
    await updateDoc(doc(db, 'items', itemId), { ...updates, updatedAt: serverTimestamp() })
    return { success: true }
  } catch (error) { return { success: false, error: error.message } }
}

export const softDeleteItemInFirestore = async (itemId) => {
  try {
    await updateDoc(doc(db, 'items', itemId), { deletedAt: serverTimestamp(), updatedAt: serverTimestamp() })
    return { success: true }
  } catch (error) { return { success: false } }
}

export const deleteItemFromFirestore = async (itemId) => {
  try { await deleteDoc(doc(db, 'items', itemId)); return { success: true } }
  catch (error) { return { success: false } }
}

export const getLeaderboard = async (limitCount = 10) => {
  try {
    const snap = await getDocs(query(collection(db, 'leaderboard'), orderBy('score', 'desc'), limit(limitCount)))
    return { success: true, records: snap.docs.map(d => ({ id: d.id, ...d.data() })) }
  } catch (error) { return { success: false, error: error.message, records: [] } }
}

export const addToLeaderboard = async (record) => {
  try { await addDoc(collection(db, 'leaderboard'), { ...record, createdAt: serverTimestamp() }); return { success: true } }
  catch { return { success: false } }
}