// Ключи для localStorage
const STORAGE_KEYS = {
  ITEMS: 'balance_game_items',
  SETTINGS: 'balance_game_settings'
}

/**
 * Получить все элементы из хранилища
 */
export function getItems() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ITEMS)
    return data ? JSON.parse(data) : []
  } catch (error) {
    console.error('Ошибка при чтении items из localStorage:', error)
    return []
  }
}

/**
 * Сохранить элементы в хранилище
 */
export function saveItems(items) {
  try {
    localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(items))
  } catch (error) {
    console.error('Ошибка при сохранении items в localStorage:', error)
  }
}

/**
 * Получить настройки
 */
export function getSettings() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS)
    const defaultSettings = {
      theme: 'light',
      colorScheme: 'default',
      viewMode: 'cards',
      confirmDelete: true
    }
    return data ? JSON.parse(data) : defaultSettings
  } catch (error) {
    console.error('Ошибка при чтении settings из localStorage:', error)
    return {
      theme: 'light',
      colorScheme: 'default',
      viewMode: 'cards',
      confirmDelete: true
    }
  }
}

/**
 * Сохранить настройки
 */
export function saveSettings(settings) {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings))
  } catch (error) {
    console.error('Ошибка при сохранении settings в localStorage:', error)
  }
}

/**
 * Инициализация начальных данных, если хранилище пустое
 */
export function initDataIfEmpty() {
  const items = getItems()
  if (items.length === 0) {
    const initialItems = [
      {
        id: crypto.randomUUID(),
        title: 'Первая игра',
        description: 'Score: 1250, время: 45 сек',
        category: 'balance',
        createdAt: Date.now(),
        isDone: true,
        deletedAt: null
      },
      {
        id: crypto.randomUUID(),
        title: 'Рекордная попытка',
        description: 'Score: 3200, время: 60 сек',
        category: 'balance',
        createdAt: Date.now() - 86400000,
        isDone: true,
        deletedAt: null
      }
    ]
    saveItems(initialItems)
  }
}