import { ref, computed, watch } from 'vue'
import { getItems, saveItems, initDataIfEmpty } from '../services/storage'

const items = ref([])
const isInitialized = ref(false)

export function useItems() {
  const initItems = () => {
    // Защита от повторной инициализации
    if (isInitialized.value) return
    
    initDataIfEmpty()
    items.value = getItems()
    isInitialized.value = true
  }

  const addItem = (item) => {
    const newItem = {
      id: crypto.randomUUID(),
      title: item.title || 'Game session',
      description: item.description || '',
      category: item.category || 'balance',
      createdAt: Date.now(),
      isDone: item.isDone !== undefined ? item.isDone : true,
      deletedAt: null,
      score: item.score || 0,
      maxCombo: item.maxCombo || 0,
      gameMode: item.gameMode || 'classic'
    }
    items.value.push(newItem)
  }

  const updateItem = (id, updates) => {
    const index = items.value.findIndex(item => item.id === id)
    if (index !== -1) {
      items.value[index] = { ...items.value[index], ...updates }
    }
  }

  const toggleDone = (id) => {
    const index = items.value.findIndex(item => item.id === id)
    if (index !== -1) {
      items.value[index].isDone = !items.value[index].isDone
    }
  }

  const softDelete = (id) => {
    const index = items.value.findIndex(item => item.id === id)
    if (index !== -1) {
      items.value[index].deletedAt = Date.now()
    }
  }

  const restoreItem = (id) => {
    const index = items.value.findIndex(item => item.id === id)
    if (index !== -1) {
      items.value[index].deletedAt = null
    }
  }

  const deleteForever = (id) => {
    items.value = items.value.filter(item => item.id !== id)
  }

  const totalCount = computed(() => items.value.length)
  const activeCount = computed(() => items.value.filter(item => item.deletedAt === null).length)
  const doneCount = computed(() => items.value.filter(item => item.isDone && item.deletedAt === null).length)
  const deletedCount = computed(() => items.value.filter(item => item.deletedAt !== null).length)

  // Автосохранение
  watch(items, (newItems) => {
    if (isInitialized.value) {
      saveItems(newItems)
    }
  }, { deep: true })

  // Первая инициализация
  if (items.value.length === 0 && !isInitialized.value) {
    initItems()
  }

  return {
    items,
    isInitialized,
    initItems,
    addItem,
    updateItem,
    toggleDone,
    softDelete,
    restoreItem,
    deleteForever,
    totalCount,
    activeCount,
    doneCount,
    deletedCount
  }
}