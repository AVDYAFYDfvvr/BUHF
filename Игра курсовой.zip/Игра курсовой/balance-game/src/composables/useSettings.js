import { ref, watch } from 'vue'
import { getSettings, saveSettings } from '../services/storage'

// Состояние на уровне модуля (Singleton)
const settings = ref(getSettings())

/**
 * Composable для управления настройками приложения
 */
export function useSettings() {
  /**
   * Обновить тему
   */
  const setTheme = (theme) => {
    settings.value.theme = theme
  }

  /**
   * Обновить цветовую схему
   */
  const setColorScheme = (scheme) => {
    settings.value.colorScheme = scheme
  }

  /**
   * Обновить режим отображения
   */
  const setViewMode = (mode) => {
    settings.value.viewMode = mode
  }

  /**
   * Включить/выключить подтверждение удаления
   */
  const setConfirmDelete = (value) => {
    settings.value.confirmDelete = value
  }

  // Автосохранение при изменении настроек
  watch(
    settings,
    (newSettings) => {
      saveSettings(newSettings)
    },
    { deep: true }
  )

  return {
    settings,
    setTheme,
    setColorScheme,
    setViewMode,
    setConfirmDelete
  }
}