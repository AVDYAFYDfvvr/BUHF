import { ref, computed } from 'vue'
import { registerUser, loginUser, logoutUser, onAuthChange, getCurrentUserData } from '../services/firebaseService'

const currentUser = ref(null)
const userData = ref(null)
const isAuthReady = ref(false)

let unsubscribe = null
let initialized = false

export function useAuth() {
  const initAuth = () => {
    if (initialized) return
    initialized = true
    
    unsubscribe = onAuthChange(async (user) => {
      currentUser.value = user
      if (user) {
        const result = await getCurrentUserData(user.uid)
        if (result.success) userData.value = result.data
      } else {
        userData.value = null
      }
      isAuthReady.value = true
    })
  }

  const signUp = async (email, password, displayName) => {
    return await registerUser(email, password, displayName)
  }

  const signIn = async (email, password) => {
    return await loginUser(email, password)
  }

  const signOut = async () => {
    userData.value = null
    return await logoutUser()
  }

  const isAdmin = computed(() => userData.value?.role === 'admin')
  const isBlocked = computed(() => userData.value?.isBlocked === true)

  return { currentUser, userData, isAuthReady, isAdmin, isBlocked, initAuth, signUp, signIn, signOut }
}