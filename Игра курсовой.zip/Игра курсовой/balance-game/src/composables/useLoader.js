import { ref } from 'vue'

// Состояние на уровне модуля (Singleton)
const isLoading = ref(false)

/**
 * Composable для управления состоянием загрузки
 */
export function useLoader() {
  /**
   * Показать лоадер
   */
  const showLoader = () => {
    isLoading.value = true
  }

  /**
   * Скрыть лоадер
   */
  const hideLoader = () => {
    isLoading.value = false
  }

  return {
    isLoading,
    showLoader,
    hideLoader
  }
}