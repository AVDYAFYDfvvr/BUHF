const sounds = {}

const loadSound = (name, url) => {
  const audio = new Audio(url)
  audio.volume = 0.3
  sounds[name] = audio
}

// Звуки можно сгенерировать программно через Web Audio API
const audioCtx = new (window.AudioContext || window.webkitAudioContext)()

const playTone = (freq, duration = 0.1, type = 'sine') => {
  const osc = audioCtx.createOscillator()
  const gain = audioCtx.createGain()
  osc.type = type; osc.frequency.value = freq
  gain.gain.value = 0.1; gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration)
  osc.connect(gain); gain.connect(audioCtx.destination)
  osc.start(); osc.stop(audioCtx.currentTime + duration)
}

export function useSound() {
  const playCollect = () => { playTone(880, 0.15); setTimeout(() => playTone(1100, 0.1), 80) }
  const playCombo = () => { playTone(660, 0.1); setTimeout(() => playTone(880, 0.1), 50); setTimeout(() => playTone(1100, 0.15), 100) }
  const playFail = () => { playTone(200, 0.3, 'sawtooth') }
  const playStart = () => { playTone(440, 0.1); setTimeout(() => playTone(660, 0.1), 100); setTimeout(() => playTone(880, 0.15), 200) }
  const playTimeChange = () => { playTone(330, 0.2); setTimeout(() => playTone(440, 0.3), 150) }

  return { playCollect, playCombo, playFail, playStart, playTimeChange }
}