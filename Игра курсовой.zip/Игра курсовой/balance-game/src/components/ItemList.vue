<template>
  <div class="item-list">
    <div v-if="filteredItems.length === 0" class="empty-state">
      <span class="empty-icon">📭</span>
      <h3>Нет элементов</h3>
      <p>Сыграйте в игру, чтобы добавить результаты</p>
      <router-link to="/create" class="btn-primary">🎮 Играть</router-link>
    </div>
    
    <div v-else class="items-grid" :class="viewMode">
      <ItemCard
        v-for="item in filteredItems"
        :key="item.id"
        :item="item"
        @toggle="handleToggle"
        @edit="handleEdit"
        @delete="handleDelete"
        @restore="handleRestore"
        @deleteForever="handleDeleteForever"
      />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import ItemCard from './ItemCard.vue'
import { useItems } from '../composables/useItems'
import { useSettings } from '../composables/useSettings'
import { useAuth } from '../composables/useAuth'

const props = defineProps({
  filter: { type: Object, default: () => ({ search: '', category: '', status: '' }) },
  showDeleted: { type: Boolean, default: false }
})

const router = useRouter()
const { items, toggleDone, softDelete, restoreItem, deleteForever } = useItems()
const { settings } = useSettings()
const { isAdmin } = useAuth()

const viewMode = computed(() => settings.value.viewMode)

const filteredItems = computed(() => {
  let filtered = props.showDeleted 
    ? items.value.filter(i => i.deletedAt) 
    : items.value.filter(i => !i.deletedAt)
  
  if (props.filter.category) filtered = filtered.filter(i => i.category === props.filter.category)
  if (props.filter.status === 'done') filtered = filtered.filter(i => i.isDone)
  else if (props.filter.status === 'active') filtered = filtered.filter(i => !i.isDone)
  if (props.filter.search) {
    const s = props.filter.search.toLowerCase()
    filtered = filtered.filter(i => i.title.toLowerCase().includes(s) || i.description.toLowerCase().includes(s))
  }
  return filtered.sort((a, b) => b.createdAt - a.createdAt)
})

const handleToggle = (id) => { if (isAdmin.value) toggleDone(id) }
const handleEdit = (id) => { if (isAdmin.value) router.push(`/edit/${id}`) }

const handleDelete = (id) => {
  if (!isAdmin.value) return
  if (settings.value.confirmDelete) {
    if (confirm('Удалить этот элемент?')) softDelete(id)
  } else softDelete(id)
}

const handleRestore = (id) => { if (isAdmin.value) restoreItem(id) }
const handleDeleteForever = (id) => { if (isAdmin.value && confirm('Удалить навсегда?')) deleteForever(id) }
</script>

<style scoped>
.item-list { min-height: 400px; }
.empty-state { text-align: center; padding: 60px 20px; background: white; border-radius: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
.empty-icon { font-size: 4em; display: block; margin-bottom: 20px; }
.empty-state h3 { color: #333; margin-bottom: 10px; }
.empty-state p { color: #666; margin-bottom: 25px; }
.items-grid { display: grid; gap: 20px; }
.items-grid.cards { grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); }
.items-grid.table { grid-template-columns: 1fr; }
.btn-primary { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; text-decoration: none; border-radius: 25px; font-weight: bold; transition: transform 0.2s; }
.btn-primary:hover { transform: translateY(-2px); }
@media (max-width: 768px) { .items-grid.cards { grid-template-columns: 1fr; } }
</style>