<template>
  <div class="item-card" :class="{ deleted: item.deletedAt }">
    <div class="card-header">
      <h3 class="card-title">{{ item.title }}</h3>
      <span class="card-category">{{ item.category }}</span>
    </div>
    
    <p class="card-description">{{ item.description }}</p>
    
    <div class="card-meta">
      <span class="meta-date">{{ formatDate(item.createdAt) }}</span>
    </div>
    
    <div v-if="isAdmin" class="card-actions">
      <button v-if="!item.deletedAt" class="btn-icon" @click="$emit('toggle', item.id)" title="Отметить">
        {{ item.isDone ? '↩️' : '✓' }}
      </button>
      <button v-if="!item.deletedAt" class="btn-icon" @click="$emit('edit', item.id)" title="Редактировать">✏️</button>
      <button v-if="!item.deletedAt" class="btn-icon danger" @click="$emit('delete', item.id)" title="Удалить">🗑️</button>
      <button v-if="item.deletedAt" class="btn-icon" @click="$emit('restore', item.id)" title="Восстановить">↩️</button>
      <button v-if="item.deletedAt" class="btn-icon danger" @click="$emit('deleteForever', item.id)" title="Удалить навсегда">❌</button>
    </div>
    
    <div v-if="item.deletedAt" class="deleted-badge">В корзине</div>
  </div>
</template>

<script setup>
import { useAuth } from '../composables/useAuth'

defineProps({ item: { type: Object, required: true } })
defineEmits(['toggle', 'edit', 'delete', 'restore', 'deleteForever'])

const { isAdmin } = useAuth()

const formatDate = (ts) => {
  if (!ts) return '-'
  const d = ts?.seconds ? new Date(ts.seconds * 1000) : new Date(ts)
  return d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}
</script>

<style scoped>
.item-card { background: white; border-radius: 15px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); transition: all 0.3s ease; position: relative; }
.item-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.15); }
.item-card.deleted { opacity: 0.7; background: #f5f5f5; }
.card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
.card-title { font-size: 1.2em; color: #333; margin: 0; }
.card-category { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.8em; font-weight: 500; }
.card-description { color: #666; margin: 10px 0; line-height: 1.5; }
.card-meta { display: flex; justify-content: space-between; margin-top: 15px; font-size: 0.85em; }
.meta-date { color: #999; }
.card-actions { display: flex; gap: 8px; margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee; }
.btn-icon { background: none; border: none; font-size: 1.2em; cursor: pointer; padding: 5px 10px; border-radius: 8px; transition: all 0.2s; }
.btn-icon:hover { background: #f0f0f0; transform: scale(1.1); }
.btn-icon.danger:hover { background: #ffebee; }
.deleted-badge { position: absolute; top: 10px; right: 10px; background: #ff4757; color: white; padding: 4px 10px; border-radius: 15px; font-size: 0.75em; }
@media (max-width: 480px) { .item-card { padding: 15px; } .card-header { flex-direction: column; gap: 8px; } .card-actions { justify-content: space-around; } }
</style>