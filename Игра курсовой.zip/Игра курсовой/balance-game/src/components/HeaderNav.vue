<template>
  <header class="header">
    <div class="header-content">
      <router-link to="/" class="logo"><span class="logo-icon">⚖️</span><span class="logo-text">Balance Master</span></router-link>
      
      <nav class="nav">
        <router-link to="/" class="nav-link" active-class="active">🏠</router-link>
        <router-link to="/create" class="nav-link" active-class="active">🎮</router-link>
        <router-link to="/stats" class="nav-link" active-class="active">📊</router-link>
        <router-link to="/archive" class="nav-link" active-class="active">🗑️</router-link>
        <router-link v-if="isAdmin" to="/admin" class="nav-link admin-link" active-class="active">👑</router-link>
        <router-link to="/settings" class="nav-link" active-class="active">⚙️</router-link>
        <router-link to="/about" class="nav-link" active-class="active">ℹ️</router-link>
      </nav>
      
      <div class="right-section">
        <UserMenu @showAuth="showAuthModal = true" />
      </div>
    </div>

    <Teleport to="body">
      <Transition name="modal">
        <div v-if="showAuthModal" class="modal-overlay" @click.self="showAuthModal = false">
          <div class="modal-content">
            <button class="modal-close" @click="showAuthModal = false">✕</button>
            <AuthForm @success="handleAuthSuccess" />
          </div>
        </div>
      </Transition>
    </Teleport>
  </header>
</template>

<script setup>
import { ref } from 'vue'
import { useItems } from '../composables/useItems'
import { useAuth } from '../composables/useAuth'
import UserMenu from './UserMenu.vue'
import AuthForm from './AuthForm.vue'

const { initItems } = useItems()
const { isAdmin, initAuth } = useAuth()

const showAuthModal = ref(false)
const handleAuthSuccess = async () => { showAuthModal.value = false; await initItems() }
initAuth()
</script>

<style scoped>
.header { background: linear-gradient(135deg, #667eea, #764ba2); padding: 12px 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); position: sticky; top: 0; z-index: 100; }
.header-content { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }
.logo { display: flex; align-items: center; gap: 8px; text-decoration: none; color: white; font-weight: bold; }
.logo-icon { font-size: 1.5em; }
.logo-text { font-size: 1.2em; }
.nav { display: flex; gap: 5px; }
.nav-link { color: rgba(255,255,255,0.8); text-decoration: none; font-weight: 500; padding: 8px 12px; border-radius: 20px; transition: all 0.2s; font-size: 1.2em; }
.nav-link:hover { background: rgba(255,255,255,0.15); color: white; }
.nav-link.active { background: rgba(255,255,255,0.25); color: white; }
.admin-link { background: rgba(255,215,0,0.15); }
.right-section { display: flex; align-items: center; gap: 15px; }
.modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(5px); display: flex; justify-content: center; align-items: center; z-index: 1000; }
.modal-content { position: relative; width: 90%; max-width: 450px; animation: slideDown 0.3s ease; }
.modal-close { position: absolute; top: 10px; right: 10px; background: rgba(0,0,0,0.1); border: none; width: 35px; height: 35px; border-radius: 50%; cursor: pointer; font-size: 1.2em; z-index: 1; }
@keyframes slideDown { from { opacity: 0; transform: translateY(-30px); } to { opacity: 1; transform: translateY(0); } }
@media (max-width: 768px) { .logo-text { display: none; } .nav-link { padding: 6px 8px; font-size: 1em; } }
</style>