<template>
  <div class="edit-view" v-if="isAdmin">
    <div class="page-header">
      <h1>✏️ Редактирование</h1>
      <router-link to="/" class="back-link">← На главную</router-link>
    </div>
    
    <div v-if="loading" class="loading-state"><div class="spinner"></div><p>Загрузка...</p></div>
    
    <div v-else-if="!item" class="error-state">
      <span class="error-icon">⚠️</span>
      <h2>Элемент не найден</h2>
      <router-link to="/" class="btn-primary">🏠 На главную</router-link>
    </div>
    
    <div v-else class="edit-form-container">
      <ItemForm :initial-item="item" @submit="handleUpdate" @cancel="handleCancel" />
    </div>
  </div>
  <div v-else class="access-denied"><h1>🚫 Доступ запрещён</h1></div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import ItemForm from '../components/ItemForm.vue'
import { useItems } from '../composables/useItems'
import { useAuth } from '../composables/useAuth'

const route = useRoute()
const router = useRouter()
const { items, updateItem } = useItems()
const { isAdmin } = useAuth()

const loading = ref(true)
const item = ref(null)

onMounted(() => {
  if (!isAdmin.value) { loading.value = false; return }
  setTimeout(() => {
    const found = items.value.find(i => i.id === route.params.id && !i.deletedAt)
    if (found) item.value = { ...found }
    loading.value = false
  }, 300)
})

const handleUpdate = (data) => { updateItem(item.value.id, data); alert('✅ Сохранено!'); router.push('/') }
const handleCancel = () => router.push('/')
</script>

<style scoped>
.edit-view { max-width: 800px; margin: 0 auto; padding: 30px 20px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
.page-header h1 { font-size: 2.5em; background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; background-clip: text; color: transparent; }
.back-link { color: #667eea; text-decoration: none; font-weight: 500; }
.loading-state { text-align: center; padding: 60px; }
.spinner { width: 50px; height: 50px; border: 4px solid #e0e0e0; border-top-color: #667eea; border-radius: 50%; animation: spin 0.8s linear infinite; margin: 0 auto 20px; }
@keyframes spin { to { transform: rotate(360deg); } }
.error-state { text-align: center; padding: 60px 30px; background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
.error-icon { font-size: 4em; display: block; margin-bottom: 20px; }
.btn-primary { display: inline-block; padding: 14px 35px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; text-decoration: none; border-radius: 25px; font-weight: bold; }
.edit-form-container { background: white; border-radius: 20px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
.access-denied { text-align: center; padding: 100px 20px; }
</style>