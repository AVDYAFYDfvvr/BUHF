<template>
  <footer class="footer">
    <div class="footer-content">
      <div class="footer-section">
        <div class="footer-logo">⚖️ Balance Master Pro</div>
        <p>Удерживайте шар в равновесии как можно дольше!</p>
      </div>
      <div class="footer-section">
        <h4>Навигация</h4>
        <router-link to="/">Главная</router-link>
        <router-link to="/create">Играть</router-link>
        <router-link to="/stats">Статистика</router-link>
        <router-link to="/archive">Архив</router-link>
        <router-link to="/settings">Настройки</router-link>
      </div>
      <div class="footer-section">
        <h4>Статистика</h4>
        <p>Всего игр: {{ totalCount }}</p>
        <p>Завершено: {{ doneCount }}</p>
        <p>В корзине: {{ deletedCount }}</p>
      </div>
      <div class="footer-section">
        <h4>© {{ currentYear }}</h4>
        <p>Курсовой проект</p>
        <p>Vue 3 + Composition API</p>
        <p>Firebase + LocalStorage</p>
      </div>
    </div>
  </footer>
</template>

<script setup>
import { computed } from 'vue'
import { useItems } from '../composables/useItems'

const { totalCount, doneCount, deletedCount } = useItems()
const currentYear = computed(() => new Date().getFullYear())
</script>

<style scoped>
.footer {
  background: linear-gradient(135deg, #1a1a2e, #16213e);
  color: white;
  padding: 50px 30px 25px;
  margin-top: auto;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
}
.footer-content {
  max-width: 1300px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 40px;
}
.footer-logo { font-size: 1.4em; font-weight: 800; margin-bottom: 12px; letter-spacing: -0.02em; }
.footer-section h4 { margin-bottom: 15px; color: #667eea; font-size: 1em; text-transform: uppercase; letter-spacing: 0.05em; }
.footer-section p { margin: 6px 0; opacity: 0.7; font-size: 0.9em; font-weight: 300; }
.footer-section a { display: block; color: rgba(255, 255, 255, 0.7); text-decoration: none; margin: 6px 0; font-size: 0.9em; transition: all 0.2s; }
.footer-section a:hover { color: #667eea; transform: translateX(5px); }
@media (max-width: 768px) { .footer-content { grid-template-columns: repeat(2, 1fr); gap: 25px; } }
@media (max-width: 480px) { .footer-content { grid-template-columns: 1fr; text-align: center; } .footer-section a:hover { transform: none; } }
</style>