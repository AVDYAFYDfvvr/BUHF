<template>
  <div class="auth-form">
    <div class="auth-tabs">
      <button 
        :class="{ active: isLogin }" 
        @click="switchToLogin"
        class="auth-tab"
      >
        Вход
      </button>
      <button 
        :class="{ active: !isLogin }" 
        @click="switchToRegister"
        class="auth-tab"
      >
        Регистрация
      </button>
    </div>

    <form @submit.prevent="handleSubmit" class="form">
      <!-- Поле ника (только при регистрации) -->
      <div v-if="!isLogin" class="form-group">
        <label for="nickname">🎮 Псевдоним (будет виден в игре)</label>
        <input 
          id="nickname"
          type="text" 
          v-model="nickname" 
          placeholder="Например: ProGamer123"
          :disabled="loading"
          minlength="3"
          maxlength="20"
        />
        <span v-if="nicknameError" class="field-error">{{ nicknameError }}</span>
      </div>

      <div class="form-group">
        <label for="email">📧 Email</label>
        <input 
          id="email"
          type="email" 
          v-model="email" 
          placeholder="email@example.com"
          :disabled="loading"
          autocomplete="email"
        />
      </div>

      <div class="form-group">
        <label for="password">🔒 Пароль</label>
        <div class="password-wrapper">
          <input 
            id="password"
            :type="showPassword ? 'text' : 'password'"
            v-model="password" 
            placeholder="Минимум 6 символов"
            :disabled="loading"
            autocomplete="current-password"
          />
          <button 
            type="button" 
            class="toggle-password"
            @click="showPassword = !showPassword"
          >
            {{ showPassword ? '🙈' : '👁️' }}
          </button>
        </div>
        <div class="password-strength" v-if="!isLogin && password">
          <div class="strength-bar">
            <div class="strength-fill" :style="{ width: passwordStrength + '%' }" :class="strengthClass"></div>
          </div>
          <span class="strength-text">{{ strengthText }}</span>
        </div>
      </div>

      <!-- Подтверждение пароля (только при регистрации) -->
      <div v-if="!isLogin" class="form-group">
        <label for="confirmPassword">🔒 Подтвердите пароль</label>
        <input 
          id="confirmPassword"
          type="password"
          v-model="confirmPassword" 
          placeholder="Повторите пароль"
          :disabled="loading"
          :class="{ 'input-error': confirmPasswordError }"
        />
        <span v-if="confirmPasswordError" class="field-error">{{ confirmPasswordError }}</span>
      </div>

      <div v-if="error" class="error-message">
        ⚠️ {{ error }}
      </div>

      <button type="submit" class="btn-submit" :disabled="loading || !isFormValid">
        {{ loading ? 'Загрузка...' : (isLogin ? '🚀 Войти' : '✨ Зарегистрироваться') }}
      </button>

      <div class="form-footer">
        <span v-if="isLogin">Нет аккаунта? <a href="#" @click.prevent="switchToRegister">Зарегистрироваться</a></span>
        <span v-else>Уже есть аккаунт? <a href="#" @click.prevent="switchToLogin">Войти</a></span>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { useAuth } from '../composables/useAuth'

const emit = defineEmits(['success'])

const { signIn, signUp, authError } = useAuth()

const isLogin = ref(true)
const email = ref('')
const password = ref('')
const nickname = ref('')
const confirmPassword = ref('')
const error = ref('')
const loading = ref(false)
const showPassword = ref(false)
const nicknameError = ref('')
const confirmPasswordError = ref('')

// Очистка ошибок при переключении вкладок
const switchToLogin = () => {
  isLogin.value = true
  error.value = ''
  nicknameError.value = ''
  confirmPasswordError.value = ''
}

const switchToRegister = () => {
  isLogin.value = false
  error.value = ''
  nicknameError.value = ''
  confirmPasswordError.value = ''
}

// Оценка сложности пароля
const passwordStrength = computed(() => {
  if (!password.value) return 0
  let strength = 0
  if (password.value.length >= 6) strength += 20
  if (password.value.length >= 8) strength += 20
  if (/[A-Z]/.test(password.value)) strength += 20
  if (/[0-9]/.test(password.value)) strength += 20
  if (/[^A-Za-z0-9]/.test(password.value)) strength += 20
  return strength
})

const strengthClass = computed(() => {
  if (passwordStrength.value <= 40) return 'weak'
  if (passwordStrength.value <= 80) return 'medium'
  return 'strong'
})

const strengthText = computed(() => {
  if (passwordStrength.value <= 40) return 'Слабый'
  if (passwordStrength.value <= 80) return 'Средний'
  return 'Надёжный'
})

// Валидация никнейма
watch(nickname, (value) => {
  if (!isLogin.value && value) {
    if (value.length < 3) {
      nicknameError.value = 'Минимум 3 символа'
    } else if (value.length > 20) {
      nicknameError.value = 'Максимум 20 символов'
    } else if (!/^[a-zA-Z0-9а-яА-ЯёЁ_-]+$/.test(value)) {
      nicknameError.value = 'Только буквы, цифры, - и _'
    } else {
      nicknameError.value = ''
    }
  }
})

// Валидация подтверждения пароля
watch([password, confirmPassword], ([pass, confirm]) => {
  if (!isLogin.value && confirm) {
    if (pass !== confirm) {
      confirmPasswordError.value = 'Пароли не совпадают'
    } else {
      confirmPasswordError.value = ''
    }
  }
})

// Валидация формы
const isFormValid = computed(() => {
  if (isLogin.value) {
    return email.value && password.value.length >= 6
  }
  return (
    nickname.value.length >= 3 &&
    !nicknameError.value &&
    email.value &&
    password.value.length >= 6 &&
    confirmPassword.value &&
    password.value === confirmPassword.value
  )
})

const handleSubmit = async () => {
  error.value = ''
  loading.value = true

  let result
  if (isLogin.value) {
    result = await signIn(email.value, password.value)
  } else {
    // Регистрация с псевдонимом
    result = await signUp(email.value, password.value, nickname.value)
  }

  loading.value = false

  if (result.success) {
    emit('success', result.user)
  } else {
    error.value = result.error || 'Произошла ошибка'
  }
}
</script>

<style scoped>
.auth-form {
  background: white;
  border-radius: 25px;
  padding: 30px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  max-width: 420px;
  margin: 0 auto;
}

.auth-tabs {
  display: flex;
  margin-bottom: 25px;
  background: #f0f0f0;
  border-radius: 15px;
  overflow: hidden;
}

.auth-tab {
  flex: 1;
  padding: 14px;
  border: none;
  background: transparent;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s;
  color: #666;
  font-size: 1em;
}

.auth-tab.active {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
}

.form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-group label {
  font-weight: 600;
  color: #333;
  font-size: 0.9em;
}

.form-group input {
  padding: 12px 16px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  font-size: 1em;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.form-group input:focus {
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-group input:disabled {
  background: #f5f5f5;
  cursor: not-allowed;
}

.form-group input.input-error {
  border-color: #ff4757;
}

.password-wrapper {
  position: relative;
}

.password-wrapper input {
  width: 100%;
  padding-right: 50px;
}

.toggle-password {
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  font-size: 1.3em;
  cursor: pointer;
  padding: 5px;
}

.field-error {
  color: #ff4757;
  font-size: 0.8em;
  margin-top: 4px;
}

.password-strength {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 6px;
}

.strength-bar {
  flex: 1;
  height: 4px;
  background: #eee;
  border-radius: 2px;
  overflow: hidden;
}

.strength-fill {
  height: 100%;
  border-radius: 2px;
  transition: width 0.3s, background 0.3s;
}

.strength-fill.weak {
  background: #ff4757;
}

.strength-fill.medium {
  background: #ffa502;
}

.strength-fill.strong {
  background: #2ed573;
}

.strength-text {
  font-size: 0.75em;
  color: #666;
  min-width: 60px;
}

.error-message {
  background: #ffebee;
  color: #c62828;
  padding: 12px 16px;
  border-radius: 10px;
  font-size: 0.9em;
  border-left: 4px solid #c62828;
}

.btn-submit {
  padding: 14px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  border: none;
  border-radius: 12px;
  font-size: 1.1em;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 5px;
}

.btn-submit:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
}

.btn-submit:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.form-footer {
  text-align: center;
  font-size: 0.9em;
  color: #666;
}

.form-footer a {
  color: #667eea;
  text-decoration: none;
  font-weight: 600;
}

.form-footer a:hover {
  text-decoration: underline;
}
</style>