<template>
  <div class="game-container" :class="[timeOfDay, { 'mobile': isMobile }]" ref="gameContainer">
    <!-- СТАРТОВЫЙ ЭКРАН -->
    <div v-if="gameState === 'start'" class="screen start-screen">
      <div class="screen-content">
        <h1 class="game-title">⚖️ Balance Master Pro</h1>
        <p class="game-subtitle">Удерживайте шар в равновесии как можно дольше!</p>
        
        <div class="feature-list">
          <div class="feature-item">🎮 Управление мышью или гироскопом</div>
          <div class="feature-item">⚡ Комбо-система и бонусы</div>
          <div class="feature-item">🌟 3 уникальных режима игры</div>
          <div class="feature-item">🌙 Динамическая смена дня и ночи</div>
          <div class="feature-item">🌐 Онлайн таблица рекордов</div>
        </div>
        
        <div class="mode-selector">
          <h3>Выберите режим:</h3>
          <div class="mode-buttons">
            <button 
              v-for="mode in gameModes" 
              :key="mode.id"
              class="mode-btn"
              :class="{ active: selectedMode === mode.id }"
              @click="selectedMode = mode.id"
            >
              <span class="mode-icon">{{ mode.icon }}</span>
              <span class="mode-name">{{ mode.name }}</span>
              <span class="mode-desc">{{ mode.description }}</span>
            </button>
          </div>
        </div>
        
        <button class="btn-primary" @click="showRules">🚀 Начать игру</button>
      </div>
    </div>

    <!-- ЭКРАН ПРАВИЛ -->
    <div v-if="gameState === 'rules'" class="screen rules-screen">
      <div class="screen-content">
        <h2>📜 Правила игры</h2>
        <div class="rules-grid">
          <div class="rule-card">
            <span class="rule-icon">🎯</span>
            <p>Наклоняй платформу мышью или наклоняя телефон</p>
          </div>
          <div class="rule-card">
            <span class="rule-icon">⚡</span>
            <p>Комбо растёт, когда шар близко к центру</p>
          </div>
          <div class="rule-card">
            <span class="rule-icon">⭐</span>
            <p>Собирай бонусы для дополнительных очков</p>
          </div>
          <div class="rule-card">
            <span class="rule-icon">⚠️</span>
            <p>Избегай препятствий и края платформы</p>
          </div>
        </div>
        <div class="mode-info">
          <h3>🎮 Особенности режимов:</h3>
          <div class="mode-info-grid">
            <div class="mode-info-card">
              <strong>🏁 Классика</strong>
              <p>60 секунд, стандартные бонусы</p>
            </div>
            <div class="mode-info-card">
              <strong>⚡ Испытание</strong>
              <p>Нет таймера! Играйте пока не упадёте</p>
            </div>
            <div class="mode-info-card">
              <strong>🎯 Мастер</strong>
              <p>30 секунд, x2 очки, но сложнее удержать</p>
            </div>
          </div>
        </div>
        <div class="button-group">
          <button class="btn-primary" @click="startGame">Играть!</button>
          <button class="btn-secondary" @click="gameState = 'start'">Назад</button>
        </div>
      </div>
    </div>

    <!-- ОСНОВНОЕ ИГРОВОЕ ПОЛЕ -->
    <div v-if="gameState === 'playing'" class="game-area">
      <div class="game-header">
        <div class="stat-card">
          <span class="stat-icon">🎯</span>
          <span class="stat-value">{{ score }}</span>
          <span class="stat-label">ОЧКИ</span>
        </div>
        <div class="stat-card" v-if="selectedMode !== 'endless'">
          <span class="stat-icon">⏱️</span>
          <span class="stat-value">{{ formatTime(timeLeft) }}</span>
          <span class="stat-label">ВРЕМЯ</span>
        </div>
        <div class="stat-card" v-else>
          <span class="stat-icon">♾️</span>
          <span class="stat-value">{{ formatSurvivalTime(survivalTime) }}</span>
          <span class="stat-label">ВЫЖИВАНИЕ</span>
        </div>
        <div class="stat-card">
          <span class="stat-icon">⚡</span>
          <span class="stat-value">{{ combo }}</span>
          <span class="stat-label">КОМБО x{{ Math.floor(combo / 10) + 1 }}</span>
        </div>
        <div class="stat-card">
          <span class="stat-icon">🏆</span>
          <span class="stat-value">{{ highScore }}</span>
          <span class="stat-label">РЕКОРД</span>
        </div>
        <div class="stat-card time-card" @click="toggleTimeOfDay">
          <span class="stat-icon">{{ timeOfDay === 'day' ? '🌞' : '🌙' }}</span>
          <span class="stat-value">{{ timeOfDay === 'day' ? 'День' : 'Ночь' }}</span>
          <span class="stat-label">{{ timeProgress }}%</span>
        </div>
      </div>

      <div v-if="combo > 10" class="combo-indicator" :class="{ 'combo-ultra': combo > 30 }">
        🔥 {{ Math.floor(combo / 10) + 1 }}x КОМБО! 🔥
      </div>

      <div class="celestial-body" :class="timeOfDay">
        <div class="celestial-inner">{{ timeOfDay === 'day' ? '☀️' : '🌙' }}</div>
        <div class="celestial-rays" v-if="timeOfDay === 'day'"></div>
      </div>

      <div class="playground" @mousemove="handleMouseMove" @touchmove="handleTouchMove" ref="playgroundRef">
        <canvas ref="particleCanvas" class="particle-canvas"></canvas>
        
        <div v-for="obstacle in obstacles" :key="obstacle.id" class="obstacle"
          :style="{ left: obstacle.x + '%', top: obstacle.y + '%', width: obstacle.size + 'px', height: obstacle.size + 'px' }">
          <div class="obstacle-inner">{{ timeOfDay === 'night' ? '🌑' : '⚠️' }}</div>
        </div>
        
        <div v-for="bonus in bonuses" :key="bonus.id" class="bonus"
          :style="{ left: bonus.x + '%', top: bonus.y + '%', animation: 'float 0.5s ease infinite' }"
          @click="collectBonus(bonus)">
          <div class="bonus-inner">{{ getBonusIcon(bonus.type) }}</div>
        </div>

        <div class="platform" :style="platformStyle">
          <div class="ball" :style="ballStyle" :class="{ 'ball-fast': Math.abs(ballVelocity) > 3 }"></div>
          <div class="ball-glow" v-if="timeOfDay === 'night'"></div>
        </div>
        
        <div v-for="spark in sparks" :key="spark.id" class="spark" :style="spark.style"></div>
        <div v-for="star in stars" :key="star.id" class="star" :style="star.style"></div>
        
        <div class="danger-left">⚠️ КРАЙ ⚠️</div>
        <div class="danger-right">⚠️ КРАЙ ⚠️</div>
      </div>

      <div class="controls-info">
        <span>🖱️ Двигайте мышью</span>
        <span v-if="isMobile">📱 Или наклоняйте телефон</span>
        <span class="time-toggle" @click="toggleTimeOfDay">🌙 Нажмите для смены времени суток</span>
      </div>
      
      <div class="difficulty-indicator">
        <div class="difficulty-bar"><div class="difficulty-fill" :style="{ width: difficultyPercent + '%' }"></div></div>
        <span>Режим: {{ currentModeName }}</span>
        <div class="weather-effect">
          <span v-if="timeOfDay === 'day'">☀️ Солнечно</span>
          <span v-else>🌙 Ночь +{{ nightDifficultyBonus }}% сложности</span>
        </div>
      </div>

      <div v-if="showTimeChangeMessage" class="time-change-message" :class="timeOfDay">{{ timeChangeMessage }}</div>
    </div>

    <!-- ЭКРАН ЗАВЕРШЕНИЯ -->
    <div v-if="gameState === 'gameover'" class="screen gameover-screen">
      <div class="screen-content">
        <h2>🎮 Игра окончена!</h2>
        <div class="final-score-card">
          <div class="final-score-value">{{ score }}</div>
          <div class="final-score-label">ИТОГОВЫЕ ОЧКИ</div>
          <div v-if="maxCombo > 5" class="max-combo">🔥 Макс. комбо x{{ Math.floor(maxCombo / 10) + 1 }}</div>
          <div class="time-stats">
            <span>🌞 Время дня: {{ dayTimePercent }}%</span>
            <span>🌙 Время ночи: {{ nightTimePercent }}%</span>
          </div>
          <div class="mode-result">Режим: {{ currentModeName }}</div>
        </div>
        
        <div class="leaderboard">
          <h3>🏅 ТАБЛИЦА ЛИДЕРОВ</h3>
          <div class="leaderboard-tabs">
            <button v-for="mode in gameModes" :key="mode.id" class="leaderboard-tab"
              :class="{ active: leaderboardMode === mode.id }" @click="switchLeaderboardMode(mode.id)">
              {{ mode.icon }} {{ mode.name }}
            </button>
          </div>
          <div class="leaderboard-list">
            <div v-for="(record, idx) in currentLeaderboard" :key="idx" class="leaderboard-item"
              :class="{ 'current-record': record.score === score && score === highScore }">
              <span class="rank">{{ idx + 1 }}</span>
              <span class="record-name">{{ record.playerName || 'Игрок' }}</span>
              <span class="record-score">{{ record.score }} очков</span>
              <span class="record-combo" v-if="record.maxCombo">🔥 x{{ record.maxCombo }}</span>
              <span class="record-date">{{ record.date }}</span>
            </div>
            <div v-if="currentLeaderboard.length === 0" class="no-records">Нет рекордов. Станьте первым!</div>
          </div>
        </div>
        
        <div class="button-group">
          <button class="btn-primary" @click="resetAndPlayAgain">🔄 Играть снова</button>
          <button class="btn-secondary" @click="gameState = 'start'">🏠 Главное меню</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onBeforeUnmount, nextTick } from 'vue'

const props = defineProps({
  playerDisplayName: { type: String, default: 'Игрок' }
})

const emit = defineEmits(['gameEnd'])

const gameState = ref('start')
const selectedMode = ref('classic')
const score = ref(0)
const timeLeft = ref(60)
const survivalTime = ref(0)
const combo = ref(0)
const maxCombo = ref(0)
const platformTilt = ref(0)
const ballX = ref(0)
const ballVelocity = ref(0)
const isGameActive = ref(true)
const obstacles = ref([])
const bonuses = ref([])
const sparks = ref([])
const stars = ref([])
const particles = ref([])
const highScore = ref(0)
const leaderboard = reactive({ classic: [], endless: [], master: [] })
const isMobile = ref(false)
const gyroAvailable = ref(false)
const currentLevel = ref(1)
const difficultyPercent = ref(0)
const timeOfDay = ref('day')
const timeProgress = ref(0)
const dayTimeCount = ref(0)
const nightTimeCount = ref(0)
const leaderboardMode = ref('classic')
const showTimeChangeMessage = ref(false)
const timeChangeMessage = ref('')
const onlineLeaderboard = ref([])

const gameContainer = ref(null)
const playgroundRef = ref(null)
const particleCanvas = ref(null)

const timer = ref(null)
const obstacleSpawnTimer = ref(null)
const bonusSpawnTimer = ref(null)
const timeCycleInterval = ref(null)
const syncInterval = ref(null)
const animationFrame = ref(null)
const starAnimationFrame = ref(null)
const particleCtx = ref(null)
const playgroundWidth = ref(800)
const lastBallX = ref(0)
const currentCycleStart = ref(0)

const gameModes = [
  { id: 'classic', name: 'Классика', icon: '🏁', description: '60 секунд', timeLimit: 60, scoreMultiplier: 1, difficulty: 1 },
  { id: 'endless', name: 'Испытание', icon: '⚡', description: 'Без времени', timeLimit: null, scoreMultiplier: 1.2, difficulty: 1.2 },
  { id: 'master', name: 'Мастер', icon: '🎯', description: '30 сек x2 очки', timeLimit: 30, scoreMultiplier: 2, difficulty: 1.5 }
]
const dayDuration = 30000
const nightDuration = 30000

const platformStyle = computed(() => ({
  transform: `rotateX(${platformTilt.value}deg)`,
  transition: 'transform 0.03s linear',
  background: timeOfDay.value === 'night' ? 'linear-gradient(135deg, #5d4037, #3e2723, #5d4037)' : 'linear-gradient(135deg, #8B4513, #A0522D, #8B4513)'
}))

const ballStyle = computed(() => {
  const maxShift = 140
  const xOffset = (ballX.value / 100) * maxShift
  const motionBlur = Math.min(Math.abs(ballVelocity.value) * 3, 10)
  const glowIntensity = timeOfDay.value === 'night' ? '0 0 20px rgba(255,215,0,0.8)' : 'none'
  return {
    transform: `translateX(${xOffset}px) translateZ(20px)`,
    filter: `blur(${motionBlur * 0.3}px)`,
    transition: 'transform 0.02s linear',
    boxShadow: glowIntensity
  }
})

const nightDifficultyBonus = computed(() => timeOfDay.value === 'night' ? 25 : 0)
const currentMode = computed(() => gameModes.find(m => m.id === selectedMode.value))
const currentModeName = computed(() => currentMode.value?.name || 'Классика')
const currentScoreMultiplier = computed(() => {
  let multiplier = currentMode.value?.scoreMultiplier || 1
  if (timeOfDay.value === 'day') multiplier *= 1.2
  if (combo.value > 30) multiplier *= 1.5
  return multiplier
})
const dayTimePercent = computed(() => {
  const total = dayTimeCount.value + nightTimeCount.value
  return total === 0 ? 0 : Math.round((dayTimeCount.value / total) * 100)
})
const nightTimePercent = computed(() => {
  const total = dayTimeCount.value + nightTimeCount.value
  return total === 0 ? 0 : Math.round((nightTimeCount.value / total) * 100)
})
const currentLeaderboard = computed(() => leaderboard[leaderboardMode.value] || [])

const detectMobile = () => { isMobile.value = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) }

const initGyroscope = () => {
  if (isMobile.value && typeof DeviceOrientationEvent !== 'undefined') {
    if (typeof DeviceOrientationEvent.requestPermission === 'function') {
      document.body.addEventListener('click', () => {
        DeviceOrientationEvent.requestPermission().then(state => {
          if (state === 'granted') { window.addEventListener('deviceorientation', handleGyro); gyroAvailable.value = true }
        })
      }, { once: true })
    } else {
      window.addEventListener('deviceorientation', handleGyro); gyroAvailable.value = true
    }
  }
}

const handleGyro = (event) => {
  if (!isGameActive.value || gameState.value !== 'playing') return
  let tilt = Math.max(-30, Math.min(30, event.beta || 0))
  platformTilt.value = (tilt / 30) * 12 * (timeOfDay.value === 'night' ? 0.7 : 1) / (currentMode.value?.difficulty || 1)
}

const generateStars = () => {
  for (let i = 0; i < 100; i++) stars.value.push({ id: i, style: { left: Math.random() * 100 + '%', top: Math.random() * 100 + '%', animationDuration: 2 + Math.random() * 3 + 's', animationDelay: Math.random() * 5 + 's', opacity: 0.3 + Math.random() * 0.7 } })
}

const animateStars = () => {
  const update = () => { if (timeOfDay.value === 'night') stars.value.forEach(s => s.style.opacity = 0.3 + Math.random() * 0.7); starAnimationFrame.value = requestAnimationFrame(update) }
  update()
}

const initParticleSystem = () => { if (particleCanvas.value) { particleCtx.value = particleCanvas.value.getContext('2d'); resizeCanvas() } }
const resizeCanvas = () => { if (particleCanvas.value && playgroundRef.value) { const r = playgroundRef.value.getBoundingClientRect(); particleCanvas.value.width = r.width; particleCanvas.value.height = r.height } }
const updatePlaygroundSize = () => { if (playgroundRef.value) { playgroundWidth.value = playgroundRef.value.clientWidth; resizeCanvas() } }

const startTimeCycle = () => {
  currentCycleStart.value = Date.now()
  timeCycleInterval.value = setInterval(() => {
    if (!isGameActive.value) return
    const elapsed = Date.now() - currentCycleStart.value
    timeProgress.value = Math.floor((elapsed / (timeOfDay.value === 'day' ? dayDuration : nightDuration)) * 100)
    if (elapsed >= (timeOfDay.value === 'day' ? dayDuration : nightDuration)) { switchTimeOfDay(); currentCycleStart.value = Date.now() }
  }, 100)
}

const switchTimeOfDay = () => {
  if (timeOfDay.value === 'day') { timeOfDay.value = 'night'; timeChangeMessage.value = '🌙 Наступила ночь!'; nightTimeCount.value += timeProgress.value }
  else { timeOfDay.value = 'day'; timeChangeMessage.value = '☀️ Наступил день!'; dayTimeCount.value += timeProgress.value }
  showTimeChangeMessage.value = true; setTimeout(() => showTimeChangeMessage.value = false, 3000)
  createTimeTransitionEffect()
  if (timeOfDay.value === 'night') ballVelocity.value *= 1.1
}

const createTimeTransitionEffect = () => {
  for (let i = 0; i < 30; i++) sparks.value.push({ id: Date.now() + i, style: { left: (Math.random() * 100) + '%', top: (Math.random() * 100) + '%', position: 'absolute', width: '6px', height: '6px', background: timeOfDay.value === 'day' ? '#ffd700' : '#c0c0c0', borderRadius: '50%', animation: 'spark 0.8s ease-out forwards', pointerEvents: 'none' } })
  setTimeout(() => sparks.value = [], 800)
}

const toggleTimeOfDay = () => { if (!isGameActive.value) return; switchTimeOfDay(); currentCycleStart.value = Date.now() }
const getBonusIcon = (type) => ({ time: '⏰', score: '⭐', super: '💎', slow: '🐢', shield: '🛡️' }[type] || '⭐')
const showRules = () => { gameState.value = 'rules' }

const startGame = () => {
  timeLeft.value = currentMode.value?.timeLimit || 60; survivalTime.value = 0; gameState.value = 'playing'
  resetGameState(); startTimer(); startPhysicsLoop(); startObstacleSpawner(); startBonusSpawner(); startTimeCycle(); animateStars()
}

const resetGameState = () => {
  score.value = 0; platformTilt.value = 0; ballX.value = 0; ballVelocity.value = 0; combo.value = 0; maxCombo.value = 0
  isGameActive.value = true; obstacles.value = []; bonuses.value = []; sparks.value = []; currentLevel.value = 1
  timeOfDay.value = 'day'; timeProgress.value = 0; dayTimeCount.value = 0; nightTimeCount.value = 0
  clearAllIntervals()
  if (particleCtx.value && particleCanvas.value) particleCtx.value.clearRect(0, 0, particleCanvas.value.width, particleCanvas.value.height)
}

const clearAllIntervals = () => {
  [timer, obstacleSpawnTimer, bonusSpawnTimer, timeCycleInterval].forEach(t => { if (t.value) clearInterval(t.value) })
}

const startTimer = () => {
  if (selectedMode.value === 'endless') {
    timer.value = setInterval(() => { if (!isGameActive.value) return; survivalTime.value++; updateScoreForSurvival() }, 1000)
  } else {
    timer.value = setInterval(() => { if (!isGameActive.value) return; if (timeLeft.value > 0) { timeLeft.value--; updateScoreForTime() } else endGame(true) }, 1000)
  }
}

const updateScoreForTime = () => {
  score.value += Math.floor(10 * (Math.floor(combo.value / 10) + 1) * currentScoreMultiplier.value)
  if (Math.abs(ballX.value) < 15) { combo.value = Math.min(combo.value + 2, 100); maxCombo.value = Math.max(maxCombo.value, combo.value) }
  else if (Math.abs(ballX.value) < 40) combo.value = Math.max(combo.value - 1, 0)
  else combo.value = Math.max(combo.value - 3, 0)
  difficultyPercent.value = selectedMode.value === 'endless' ? Math.min(100, survivalTime.value / 90 * 100) : (60 - timeLeft.value) / 60 * 100
  if (timeOfDay.value === 'night') difficultyPercent.value = Math.min(100, difficultyPercent.value + 10)
  if (score.value > highScore.value) { highScore.value = score.value; localStorage.setItem(`balancing_highscore_${selectedMode.value}`, highScore.value) }
}

const updateScoreForSurvival = () => {
  score.value += Math.floor(15 * (Math.floor(combo.value / 10) + 1) * currentScoreMultiplier.value)
  if (Math.abs(ballX.value) < 15) { combo.value = Math.min(combo.value + 2, 100); maxCombo.value = Math.max(maxCombo.value, combo.value) }
  else if (Math.abs(ballX.value) < 40) combo.value = Math.max(combo.value - 1, 0)
  else combo.value = Math.max(combo.value - 3, 0)
  difficultyPercent.value = Math.min(100, survivalTime.value / 90 * 100)
  if (timeOfDay.value === 'night') difficultyPercent.value = Math.min(100, difficultyPercent.value + 10)
  if (score.value > highScore.value) { highScore.value = score.value; localStorage.setItem(`balancing_highscore_${selectedMode.value}`, highScore.value) }
}

const startObstacleSpawner = () => {
  obstacleSpawnTimer.value = setInterval(() => {
    if (!isGameActive.value) return
    let spawnChance = Math.min(0.5, 0.2 + (difficultyPercent.value / 100) * 0.5)
    if (timeOfDay.value === 'night') spawnChance *= 1.3
    if (selectedMode.value === 'master') spawnChance *= 1.4
    if (Math.random() < spawnChance && obstacles.value.length < 6) {
      const id = Date.now() + Math.random()
      obstacles.value.push({ id, x: 10 + Math.random() * 80, y: 60 + Math.random() * 30, size: 25 + Math.random() * 25 })
      setTimeout(() => obstacles.value = obstacles.value.filter(o => o.id !== id), 3000)
    }
  }, 2000)
}

const startBonusSpawner = () => {
  bonusSpawnTimer.value = setInterval(() => {
    if (!isGameActive.value) return
    let spawnRate = 0.3
    if (timeOfDay.value === 'day') spawnRate = 0.45
    if (selectedMode.value === 'classic') spawnRate = 0.35
    if (Math.random() < spawnRate && bonuses.value.length < 4) {
      const bonusTypes = combo.value > 20 ? ['time', 'score', 'super'] : ['time', 'score']
      if (selectedMode.value === 'master') bonusTypes.push('slow')
      const id = Date.now() + Math.random()
      bonuses.value.push({ id, x: 10 + Math.random() * 80, y: 60 + Math.random() * 30, type: bonusTypes[Math.floor(Math.random() * bonusTypes.length)] })
      setTimeout(() => bonuses.value = bonuses.value.filter(b => b.id !== id), 4000)
    }
  }, 5000)
}

const collectBonus = (bonus) => {
  if (!isGameActive.value) return
  bonuses.value = bonuses.value.filter(b => b.id !== bonus.id)
  switch(bonus.type) {
    case 'time': if (selectedMode.value !== 'endless') timeLeft.value = Math.min(timeLeft.value + 5, 90); score.value += 50; break
    case 'super': score.value += 250; combo.value = Math.min(combo.value + 25, 100); break
    case 'slow': ballVelocity.value *= 0.7; score.value += 150; break
    default: score.value += 100; combo.value = Math.min(combo.value + 15, 100)
  }
  createSparkEffect(bonus.type === 'super' ? 'rainbow' : bonus.type === 'slow' ? 'blue' : 'gold')
}

const showBonusMessage = (message, type) => {
  const d = document.createElement('div'); d.textContent = message
  d.style.cssText = `position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);font-size:1.5em;font-weight:bold;z-index:1000;animation:bonusPop 0.5s ease-out forwards;pointer-events:none;background:${type==='rainbow'?'linear-gradient(45deg,red,orange,yellow,green,blue,indigo,violet)':type==='gold'?'#ffd700':'#00ff88'};color:white;padding:10px 20px;border-radius:50px;white-space:nowrap`
  document.body.appendChild(d); setTimeout(() => d.remove(), 500)
}

const startPhysicsLoop = () => {
  const update = () => { if (gameState.value === 'playing' && isGameActive.value) { applyPhysics(); checkCollisions(); updateParticles(); checkBallFell(); animationFrame.value = requestAnimationFrame(update) } }
  update()
}

const applyPhysics = () => {
  let tiltForce = platformTilt.value / 12
  if (timeOfDay.value === 'night') tiltForce *= 1.15
  if (selectedMode.value === 'master') tiltForce *= 1.3
  ballVelocity.value += tiltForce * 0.6; ballVelocity.value *= 0.985
  ballX.value += ballVelocity.value
  if (Math.abs(ballVelocity.value) > 2 && Math.random() < 0.3) createParticle(ballX.value, ballVelocity.value)
  if (ballX.value > 100) { ballX.value = 100; ballVelocity.value = 0 }
  if (ballX.value < -100) { ballX.value = -100; ballVelocity.value = 0 }
}

const createParticle = (bx, v) => {
  if (!particleCtx.value || !particleCanvas.value) return
  particles.value.push({ x: particleCanvas.value.width / 2 + (bx / 100) * 140, y: particleCanvas.value.height - 100, vx: (Math.random() - 0.5) * 3, vy: -Math.random() * 3, life: 1, size: 3 + Math.random() * 4, color: timeOfDay.value === 'day' ? '255,200,100' : '200,200,255' })
}

const updateParticles = () => {
  if (!particleCtx.value || !particleCanvas.value) return
  particleCtx.value.clearRect(0, 0, particleCanvas.value.width, particleCanvas.value.height)
  particles.value = particles.value.filter(p => { p.x += p.vx; p.y += p.vy; p.life -= 0.03; p.size *= 0.98; if (p.life > 0) { particleCtx.value.beginPath(); particleCtx.value.arc(p.x, p.y, p.size, 0, Math.PI * 2); particleCtx.value.fillStyle = `rgba(${p.color},${p.life*0.6})`; particleCtx.value.fill(); return true } return false })
}

const createSparkEffect = (color = 'orange') => {
  const colors = { orange: '#ff6600', gold: '#ffd700', green: '#00ff88', blue: '#4488ff', rainbow: 'linear-gradient(45deg, red, orange, yellow, green, blue, indigo, violet)' }
  for (let i = 0; i < 12; i++) sparks.value.push({ id: Date.now() + i, style: { left: (50 + (Math.random() - 0.5) * 30) + '%', top: '75%', position: 'absolute', width: '5px', height: '5px', background: colors[color] || '#ff6600', borderRadius: '50%', animation: 'spark 0.5s ease-out forwards', pointerEvents: 'none' } })
  setTimeout(() => sparks.value = [], 500)
}

const checkCollisions = () => {
  const bsx = 50 + (ballX.value / 100) * 28
  obstacles.value.forEach(o => { if (Math.abs(bsx - o.x) < 8 && o.y > 65 && o.y < 85) { ballVelocity.value *= -0.5; score.value = Math.max(0, score.value - (timeOfDay.value === 'night' ? 80 : selectedMode.value === 'master' ? 100 : 50)); combo.value = Math.max(0, combo.value - 10) } })
  bonuses.value.forEach(b => { if (Math.abs(bsx - b.x) < 10) collectBonus(b) })
}

const checkBallFell = () => {
  const threshold = selectedMode.value === 'master' ? 1.0 : timeOfDay.value === 'night' ? 1.2 : 1.5
  if (Math.abs(ballX.value) >= 97 && Math.abs(ballVelocity.value) > threshold) endGame(false)
  if (Math.abs(ballX.value) > 100) endGame(false)
}

const handleMouseMove = (e) => {
  if (!isGameActive.value || gameState.value !== 'playing' || !playgroundRef.value) return
  const rect = playgroundRef.value.getBoundingClientRect()
  let tilt = (((e.clientX - rect.left) / rect.width) * 24) - 12
  if (timeOfDay.value === 'night') tilt *= 0.85
  if (selectedMode.value === 'master') tilt *= 0.8
  platformTilt.value = Math.max(-12, Math.min(12, tilt))
}

const handleTouchMove = (e) => {
  e.preventDefault()
  if (!isGameActive.value || gameState.value !== 'playing' || !playgroundRef.value) return
  const rect = playgroundRef.value.getBoundingClientRect()
  let tilt = (((e.touches[0].clientX - rect.left) / rect.width) * 24) - 12
  if (timeOfDay.value === 'night') tilt *= 0.85
  if (selectedMode.value === 'master') tilt *= 0.8
  platformTilt.value = Math.max(-12, Math.min(12, tilt))
}

const endGame = () => {
  if (!isGameActive.value) return
  isGameActive.value = false; clearAllIntervals()
  saveScore(score.value, maxCombo.value); gameState.value = 'gameover'
  emit('gameEnd', { score: score.value, maxCombo: maxCombo.value, mode: selectedMode.value, survivalTime: survivalTime.value, timeLeft: timeLeft.value })
}

const saveScore = (sv, mcv) => {
  const cl = Math.floor(mcv / 10) + 1
  leaderboard[selectedMode.value].push({ playerName: props.playerDisplayName, score: sv, maxCombo: cl > 1 ? cl : null, date: new Date().toLocaleString(), mode: selectedMode.value })
  leaderboard[selectedMode.value].sort((a, b) => b.score - a.score)
  if (leaderboard[selectedMode.value].length > 10) leaderboard[selectedMode.value] = leaderboard[selectedMode.value].slice(0, 10)
  localStorage.setItem('balancing_leaderboard_all', JSON.stringify(leaderboard))
  if (sv > highScore.value) { highScore.value = sv; localStorage.setItem(`balancing_highscore_${selectedMode.value}`, highScore.value) }
}

const syncToOnline = async (r) => {
  try { await fetch('https://jsonplaceholder.typicode.com/posts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(r) }) } catch {}
}

const startOnlineSync = () => {
  syncInterval.value = setInterval(async () => {
    try { const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=10'); if (res.ok) { const d = await res.json(); onlineLeaderboard.value = d.map(p => ({ playerName: `Player ${p.id}`, score: p.id * 100, date: new Date().toLocaleString() })) } } catch {}
  }, 30000)
}

const loadLeaderboard = () => {
  const saved = localStorage.getItem('balancing_leaderboard_all')
  if (saved) Object.assign(leaderboard, JSON.parse(saved))
}

const loadHighScore = () => {
  const saved = localStorage.getItem(`balancing_highscore_${selectedMode.value}`)
  highScore.value = saved ? parseInt(saved) : (leaderboard[selectedMode.value]?.[0]?.score || 0)
}

const switchLeaderboardMode = (id) => { leaderboardMode.value = id }

const resetAndPlayAgain = () => { resetGameState(); startGame() }

const formatTime = (s) => s == null ? '∞' : `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toString().padStart(2,'0')}`
const formatSurvivalTime = (s) => `${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`

onMounted(() => {
  loadLeaderboard(); loadHighScore(); detectMobile(); initGyroscope(); generateStars()
  window.addEventListener('resize', updatePlaygroundSize)
  nextTick(() => { updatePlaygroundSize(); initParticleSystem() })
  startOnlineSync()
})

onBeforeUnmount(() => {
  clearAllIntervals()
  if (animationFrame.value) cancelAnimationFrame(animationFrame.value)
  if (starAnimationFrame.value) cancelAnimationFrame(starAnimationFrame.value)
  if (timeCycleInterval.value) clearInterval(timeCycleInterval.value)
  if (syncInterval.value) clearInterval(syncInterval.value)
  window.removeEventListener('resize', updatePlaygroundSize)
  if (gyroAvailable.value) window.removeEventListener('deviceorientation', handleGyro)
})
</script>

<style scoped>
* { margin: 0; padding: 0; box-sizing: border-box; user-select: none; }
.game-container { min-height: 100vh; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); display: flex; justify-content: center; align-items: center; font-family: 'Segoe UI', 'Poppins', Tahoma, Geneva, Verdana, sans-serif; transition: background 0.5s ease; padding: 20px; }
.game-container.day { background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%); }
.game-container.night { background: linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%); }
.screen { background: rgba(255, 255, 255, 0.98); border-radius: 40px; padding: 40px; max-width: 750px; width: 90%; text-align: center; box-shadow: 0 25px 50px rgba(0,0,0,0.4); backdrop-filter: blur(10px); animation: slideUp 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55); }
@keyframes slideUp { from { opacity: 0; transform: translateY(50px) scale(0.9); } to { opacity: 1; transform: translateY(0) scale(1); } }
.game-title { font-size: 3em; background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; background-clip: text; color: transparent; margin-bottom: 15px; }
.game-subtitle { color: #666; margin-bottom: 30px; font-size: 1.1em; }
.feature-list { background: linear-gradient(135deg, #f5f7fa, #c3cfe2); border-radius: 20px; padding: 20px; margin: 20px 0; }
.feature-item { padding: 8px; font-size: 1em; color: #333; }
.mode-selector { margin: 25px 0; }
.mode-selector h3 { margin-bottom: 15px; color: #333; }
.mode-buttons { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; }
.mode-btn { background: linear-gradient(135deg, #f5f7fa, #e0e5ec); border: none; border-radius: 20px; padding: 15px 10px; cursor: pointer; transition: all 0.3s ease; text-align: center; }
.mode-btn.active { background: linear-gradient(135deg, #667eea, #764ba2); color: white; transform: scale(1.05); box-shadow: 0 10px 25px rgba(102,126,234,0.3); }
.mode-icon { font-size: 2em; display: block; margin-bottom: 5px; }
.mode-name { font-weight: bold; display: block; font-size: 1em; }
.mode-desc { font-size: 0.8em; opacity: 0.8; }
.rules-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 25px 0; }
.rule-card { background: linear-gradient(135deg, #667eea20, #764ba220); padding: 15px; border-radius: 20px; transition: transform 0.2s; }
.rule-card:hover { transform: translateY(-3px); }
.rule-icon { font-size: 2em; display: block; margin-bottom: 10px; }
.mode-info { margin: 20px 0; padding: 20px; background: #f0f0f0; border-radius: 20px; }
.mode-info h3 { margin-bottom: 15px; }
.mode-info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; }
.mode-info-card { background: white; padding: 12px; border-radius: 15px; text-align: left; }
.mode-info-card strong { color: #667eea; display: block; margin-bottom: 5px; }
.mode-info-card p { font-size: 0.85em; color: #666; }
.btn-primary, .btn-secondary { border: none; padding: 14px 35px; font-size: 1.1em; border-radius: 50px; cursor: pointer; margin: 10px; transition: all 0.3s ease; font-weight: bold; }
.btn-primary { background: linear-gradient(135deg, #667eea, #764ba2); color: white; box-shadow: 0 5px 15px rgba(102,126,234,0.4); }
.btn-primary:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(102,126,234,0.5); }
.btn-secondary { background: #95a5a6; color: white; }
.btn-secondary:hover { background: #7f8c8d; transform: translateY(-2px); }
.button-group { display: flex; justify-content: center; gap: 15px; margin-top: 20px; }
.game-area { width: 95%; max-width: 1300px; background: rgba(255, 255, 255, 0.95); border-radius: 35px; padding: 25px; box-shadow: 0 25px 50px rgba(0,0,0,0.3); transition: background 0.3s ease; }
.game-header { display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin-bottom: 25px; }
.stat-card { background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 20px; padding: 15px; text-align: center; color: white; transition: transform 0.2s; cursor: pointer; }
.stat-card:hover { transform: translateY(-3px); }
.stat-icon { font-size: 1.8em; display: block; margin-bottom: 5px; }
.stat-value { font-size: 1.8em; font-weight: bold; display: block; }
.stat-label { font-size: 0.8em; opacity: 0.9; }
.time-card { background: linear-gradient(135deg, #f39c12, #e67e22); }
.combo-indicator { position: absolute; top: 100px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg, #ff6b6b, #ee5a24); color: white; padding: 10px 25px; border-radius: 50px; font-weight: bold; font-size: 1.2em; animation: comboPulse 0.3s ease; z-index: 10; white-space: nowrap; }
.combo-ultra { background: linear-gradient(135deg, #ff4757, #ff6b81); font-size: 1.5em; animation: comboUltra 0.5s infinite; }
@keyframes comboPulse { 0%, 100% { transform: translateX(-50%) scale(1); } 50% { transform: translateX(-50%) scale(1.1); } }
@keyframes comboUltra { 0%, 100% { text-shadow: 0 0 10px rgba(255,255,255,0.8); } 50% { text-shadow: 0 0 20px rgba(255,255,255,1); } }
.celestial-body { position: absolute; top: 20px; right: 20px; width: 60px; height: 60px; border-radius: 50%; z-index: 15; animation: float 3s ease-in-out infinite; }
.celestial-body.day { background: radial-gradient(circle, #ffd700, #ff8c00); box-shadow: 0 0 30px rgba(255,215,0,0.8); }
.celestial-body.night { background: radial-gradient(circle, #e0e0e0, #a0a0a0); box-shadow: 0 0 20px rgba(255,255,255,0.5); }
.celestial-inner { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; font-size: 2.5em; }
.celestial-rays { position: absolute; top: -10px; left: -10px; right: -10px; bottom: -10px; border-radius: 50%; background: radial-gradient(circle, rgba(255,215,0,0.3), transparent); animation: pulse 2s ease-in-out infinite; }
@keyframes pulse { 0%, 100% { transform: scale(1); opacity: 0.5; } 50% { transform: scale(1.2); opacity: 0.8; } }
.playground { position: relative; height: 500px; background: linear-gradient(135deg, #1e3c72, #2a5298); border-radius: 30px; overflow: hidden; cursor: none; margin-bottom: 20px; perspective: 1000px; box-shadow: inset 0 0 30px rgba(0,0,0,0.3); transition: background 0.5s ease; }
.game-container.day .playground { background: linear-gradient(135deg, #87CEEB, #98D8C8); }
.game-container.night .playground { background: linear-gradient(135deg, #0a0a2a, #1a1a3a); }
.particle-canvas { position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 5; }
.platform { position: absolute; bottom: 80px; left: 10%; width: 80%; height: 35px; border-radius: 20px; transform-style: preserve-3d; box-shadow: 0 10px 30px rgba(0,0,0,0.4); z-index: 2; transition: background 0.3s ease; }
.platform::before { content: ''; position: absolute; top: -12px; left: 0; right: 0; height: 12px; background: linear-gradient(135deg, #CD853F, #DEB887); border-radius: 8px 8px 0 0; }
.ball { position: absolute; top: -25px; left: 50%; width: 50px; height: 50px; background: radial-gradient(circle at 35% 35%, #FFD700, #FF8C00); border-radius: 50%; transform: translateX(-50%) translateZ(25px); transition: filter 0.05s linear, box-shadow 0.3s ease; z-index: 3; }
.ball::after { content: ''; position: absolute; top: 12px; left: 14px; width: 12px; height: 12px; background: rgba(255,255,255,0.8); border-radius: 50%; }
.ball-fast { filter: blur(2px); }
.ball-glow { position: absolute; top: -10px; left: -10px; right: -10px; bottom: -10px; border-radius: 50%; background: radial-gradient(circle, rgba(255,215,0,0.4), transparent); animation: glowPulse 1s ease-in-out infinite; }
@keyframes glowPulse { 0%, 100% { transform: scale(1); opacity: 0.5; } 50% { transform: scale(1.3); opacity: 1; } }
.obstacle { position: absolute; z-index: 4; pointer-events: none; }
.obstacle-inner { width: 100%; height: 100%; background: linear-gradient(135deg, #e74c3c, #c0392b); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2em; animation: obstaclePulse 1s ease infinite; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
@keyframes obstaclePulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
.bonus { position: absolute; z-index: 4; cursor: pointer; transition: transform 0.2s; }
.bonus:hover { transform: scale(1.1); }
.bonus-inner { width: 45px; height: 45px; background: radial-gradient(circle, #f39c12, #e67e22); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5em; box-shadow: 0 0 15px rgba(243,156,18,0.6); }
@keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-8px); } }
.star { position: absolute; width: 2px; height: 2px; background: white; border-radius: 50%; animation: twinkle 2s ease-in-out infinite; }
@keyframes twinkle { 0%, 100% { opacity: 0.3; transform: scale(1); } 50% { opacity: 1; transform: scale(1.5); } }
.danger-left, .danger-right { position: absolute; bottom: 80px; color: #ff4757; font-weight: bold; font-size: 0.9em; text-shadow: 0 0 5px rgba(255,255,255,0.8); z-index: 1; }
.danger-left { left: 5%; } .danger-right { right: 5%; }
.controls-info { display: flex; justify-content: space-between; align-items: center; padding: 15px; background: #ecf0f1; border-radius: 20px; color: #2c3e50; font-weight: bold; margin-bottom: 15px; flex-wrap: wrap; gap: 10px; }
.time-toggle { cursor: pointer; padding: 5px 15px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border-radius: 20px; transition: transform 0.2s; }
.time-toggle:hover { transform: scale(1.05); }
.difficulty-indicator { display: flex; align-items: center; gap: 15px; padding: 10px; }
.difficulty-bar { flex: 1; height: 8px; background: #ddd; border-radius: 10px; overflow: hidden; }
.difficulty-fill { height: 100%; background: linear-gradient(90deg, #00ff88, #ff4757); border-radius: 10px; transition: width 0.3s ease; }
.weather-effect { padding: 5px 15px; background: rgba(0,0,0,0.1); border-radius: 20px; font-size: 0.9em; }
.time-change-message { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); padding: 15px 30px; border-radius: 50px; font-weight: bold; font-size: 1.2em; z-index: 100; animation: messagePop 0.3s ease-out; white-space: nowrap; }
.time-change-message.day { background: linear-gradient(135deg, #ffd700, #ff8c00); color: white; }
.time-change-message.night { background: linear-gradient(135deg, #4a4a4a, #2a2a2a); color: #ffd700; }
@keyframes messagePop { 0% { opacity: 0; transform: translate(-50%, -50%) scale(0.5); } 100% { opacity: 1; transform: translate(-50%, -50%) scale(1); } }
.gameover-screen { max-width: 800px; }
.final-score-card { background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 30px; padding: 25px; margin: 20px 0; color: white; }
.final-score-value { font-size: 4em; font-weight: bold; }
.max-combo { margin-top: 10px; font-size: 1.2em; color: #ffd700; }
.time-stats { display: flex; justify-content: center; gap: 20px; margin-top: 15px; font-size: 0.9em; }
.mode-result { margin-top: 10px; font-size: 1em; opacity: 0.9; }
.leaderboard { margin: 20px 0; border-radius: 20px; background: #f8f9fa; overflow: hidden; }
.leaderboard h3 { padding: 15px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
.leaderboard-tabs { display: flex; background: #e9ecef; }
.leaderboard-tab { flex: 1; padding: 12px; border: none; background: none; cursor: pointer; font-size: 1em; transition: all 0.2s; }
.leaderboard-tab.active { background: white; color: #667eea; font-weight: bold; border-bottom: 3px solid #667eea; }
.leaderboard-list { max-height: 280px; overflow-y: auto; }
.leaderboard-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; border-bottom: 1px solid #e0e0e0; }
.current-record { background: #fff3cd; }
.rank { font-weight: bold; font-size: 1.2em; color: #667eea; width: 40px; }
.record-name { font-weight: 500; min-width: 80px; }
.record-score { font-weight: bold; flex: 1; text-align: center; }
.record-combo { color: #ff6b6b; font-size: 0.85em; min-width: 60px; }
.record-date { font-size: 0.75em; color: #7f8c8d; min-width: 120px; }
.no-records { padding: 30px; text-align: center; color: #999; }
@media (max-width: 1024px) { .game-header { grid-template-columns: repeat(3, 1fr); } .mode-buttons, .mode-info-grid { grid-template-columns: 1fr; } }
@media (max-width: 768px) { .playground { height: 400px; } .platform { height: 25px; bottom: 60px; } .ball { width: 40px; height: 40px; top: -20px; } .ball::after { top: 10px; left: 11px; width: 10px; height: 10px; } .game-title { font-size: 2em; } .stat-value { font-size: 1.2em; } }
@media (max-width: 480px) { .game-header { grid-template-columns: repeat(2, 1fr); } .screen { padding: 25px; } }
</style>