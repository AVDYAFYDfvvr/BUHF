<template>
  <div class="user-menu">
    <div v-if="currentUser" class="user-info">
      <div class="avatar">
        {{ userInitial }}
      </div>
      <span class="user-name">{{ currentUser.displayName || 'Пользователь' }}</span>
      <button @click="handleLogout" class="logout-btn" title="Выйти">
        🚪
      </button>
    </div>
    <div v-else class="auth-buttons">
      <button @click="$emit('showAuth')" class="login-btn">
        🔑 Войти
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useAuth } from '../composables/useAuth'

const emit = defineEmits(['showAuth'])

const { currentUser, signOut } = useAuth()

const userInitial = computed(() => {
  if (!currentUser.value) return '?'
  const name = currentUser.value.displayName || currentUser.value.email || 'U'
  return name.charAt(0).toUpperCase()
})

const handleLogout = async () => {
  await signOut()
}
</script>

<style scoped>
.user-menu {
  display: flex;
  align-items: center;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 1.2em;
}

.user-name {
  color: white;
  font-weight: 500;
}

.logout-btn {
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  padding: 6px 10px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 1.2em;
  transition: background 0.2s;
}

.logout-btn:hover {
  background: rgba(255, 255, 255, 0.3);
}

.login-btn {
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  padding: 10px 20px;
  border-radius: 25px;
  cursor: pointer;
  font-weight: 600;
  transition: background 0.2s;
}

.login-btn:hover {
  background: rgba(255, 255, 255, 0.3);
}
</style>