<template>
  <div class="item-filters">
    <div class="filter-group">
      <input
        type="text"
        :value="filter.search"
        @input="$emit('update:filter', { ...filter, search: $event.target.value })"
        placeholder="🔍 Поиск..."
        class="search-input"
      />
    </div>
    
    <div class="filter-group">
      <select
        :value="filter.category"
        @change="$emit('update:filter', { ...filter, category: $event.target.value })"
        class="filter-select"
      >
        <option value="">Все категории</option>
        <option value="balance">Balance Game</option>
        <option value="classic">Классика</option>
        <option value="endless">Испытание</option>
        <option value="master">Мастер</option>
      </select>
    </div>
    
    <div class="filter-group">
      <select
        :value="filter.status"
        @change="$emit('update:filter', { ...filter, status: $event.target.value })"
        class="filter-select"
      >
        <option value="">Все статусы</option>
        <option value="active">Активные</option>
        <option value="done">Завершённые</option>
      </select>
    </div>
    
    <div class="filter-stats">
      <span class="stat">Найдено: {{ count }}</span>
      <button 
        v-if="hasActiveFilters"
        @click="$emit('update:filter', { search: '', category: '', status: '' })"
        class="clear-btn"
      >
        ✕ Сбросить
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  filter: {
    type: Object,
    required: true,
    default: () => ({ search: '', category: '', status: '' })
  },
  count: {
    type: Number,
    default: 0
  }
})

defineEmits(['update:filter'])

const hasActiveFilters = computed(() => {
  return props.filter.search || props.filter.category || props.filter.status
})
</script>

<style scoped>
.item-filters {
  background: white;
  border-radius: 20px;
  padding: 20px;
  margin-bottom: 25px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  align-items: center;
}

.filter-group {
  flex: 1;
  min-width: 200px;
}

.search-input {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  font-size: 1em;
  outline: none;
  transition: border-color 0.2s;
}

.search-input:focus {
  border-color: #667eea;
}

.filter-select {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  font-size: 1em;
  background: white;
  cursor: pointer;
  outline: none;
}

.filter-select:focus {
  border-color: #667eea;
}

.filter-stats {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-left: auto;
}

.stat {
  color: #666;
  font-weight: 500;
}

.clear-btn {
  background: none;
  border: none;
  color: #667eea;
  cursor: pointer;
  font-weight: 500;
  padding: 5px 10px;
  border-radius: 8px;
  transition: background 0.2s;
}

.clear-btn:hover {
  background: #f0f0f0;
}

@media (max-width: 768px) {
  .item-filters {
    flex-direction: column;
    align-items: stretch;
  }
  
  .filter-group {
    min-width: auto;
  }
  
  .filter-stats {
    margin-left: 0;
    justify-content: space-between;
  }
}
</style>