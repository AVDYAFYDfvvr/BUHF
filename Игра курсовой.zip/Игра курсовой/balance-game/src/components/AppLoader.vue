<template>
  <Transition name="fade">
    <div v-if="isLoading" class="loader-overlay" @click.prevent>
      <div class="loader-content">
        <div class="loader-spinner"></div>
        <p class="loader-text">Загрузка...</p>
      </div>
    </div>
  </Transition>
</template>

<script setup>
import { useLoader } from '../composables/useLoader'

const { isLoading } = useLoader()
</script>

<style scoped>
.loader-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(5px);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.loader-content {
  text-align: center;
}

.loader-spinner {
  width: 60px;
  height: 60px;
  border: 5px solid rgba(255, 255, 255, 0.3);
  border-top-color: #667eea;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  margin: 0 auto 20px;
}

.loader-text {
  color: white;
  font-size: 1.2em;
  font-weight: 500;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>